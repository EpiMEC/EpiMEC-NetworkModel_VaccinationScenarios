T = 367;%171; % 171
coefMin  = 0.014;% I Sim .014

simulations   = 20;
direc = './info/';
nameFile1 = 'proy_';
nameFile2 = 'mapAct_';
nameFile3 = 'mapAcum_';
nameFile4 = 'mapUCI_';
nameFile5 = 'mapH_';
nameFile6 = 'mapMuertes_';
nameFile7 = 'mapU_';

parfor sim = 1:simulations
    [data, dataMap,dataMapAcum,...
        dataMapUCI,dataMapH,dataMapMuertes,dataMapU] = runV4(T,coefMin);
    parsave(sim,data,direc,nameFile1);
    parsave(sim,dataMap,direc,nameFile2);
    parsave(sim,dataMapAcum,direc,nameFile3);
    parsave(sim,dataMapUCI,direc,nameFile4);
    parsave(sim,dataMapH,direc,nameFile5);
    parsave(sim,dataMapMuertes,direc,nameFile6);
    parsave(sim,dataMapU,direc,nameFile7);
end

function [export,dataMap,dataMapAcum,...
     dataMapUCI,dataMapH,dataMapMuertes,dataMapU] = runV4(T,coefMin)
tic

% Definition of variables
parameters          % list of disease parameters

DaysToRecoverDiagnosed     = 10;     % tiempo promedio en D
DaysToRecoverUndiagnosed   = 10;     % tiempo promedio en U

% options
countyInfo = true;
testTime  = 5;
trigger   = 0.005; % more connectivity if smaller
coefFam   = .8;
coefMasc  = .0945;
coefDist  = .0420;
coefMD    = .0189; %(1-EM)(1-PD)
coefSpor  = .50;
pUseMask = .7;
direc     = './info/';
nexosFile = 'Nexos7-Oct16';
nexosTab  = 'Sheet 1';

canton2region = xlsread([direc '5Regiones'],'Regiones','F2:G82');
canton2region = sortrows(canton2region);
canton2region = canton2region(:,2);
minmaxBubble   = xlsread([direc '5Regiones'],'Regiones','K2:L6');

tic

% demographic info
[familyInfo,idToCounty,idToFamily,~,...
    cumsum_people_per_county,idToAge,familyAccum] = start_family(direc);
familyAdded = false(numel(familyInfo),1); % true if family is already in graph
N = sum(familyInfo);                      % total population

% Preasign degree for each node
% coworkers: uniform value in [min_coworkers, min_coworkers+max_dev_coworkers-1]
degreeContacts = uint8(min_coworkers+randi(max_dev_coworkers,N,1)-1);
degreeSporadic = uint8(min_sporadic +randi(max_dev_sporadic, N,1)-1);

% "national id" on the graph
GraphIDtoNationID = zeros(1,N,'uint32'); % people id when included in graph
numberNodesGraph  = 0;                   % number of nodes on graph

% national id to local graph index
idToGraph = zeros(1,N,'uint32');

% keep track of added ids (so no need to use ismember)
notadded = true(N,1);

% compartmental states at time t
SS    = true(N,1);  % susceptible
SE    = false(N,1); % asymptomatic
SD    = false(N,1); % diagnosed (-> R)
SDH   = false(N,1); % diagnosed (-> H)
SDD   = false(N,1); % diagnosed (-> D)
SU    = false(N,1); % undiagnosed (-> R)
SUH   = false(N,1); % undiagnosed (-> H)
SUD   = false(N,1); % undiagnosed (-> D)
SR    = false(N,1); % recovered
SH    = false(N,1); % hospitalized
SUCI  = false(N,1); % intensive care unit
SDead = false(N,1); % dead patient

% datos diarios (totales y por grupo etario)
totalD     = zeros(1,T+1,'uint32'); % incluye SD, SDH, SH, SUCI, SDD
totalU     = zeros(1,T+1,'uint32'); % incluye SU, SUH, SUD
totalH     = zeros(1,T+1,'uint32');
totalUCI   = zeros(1,T+1,'uint32');
totalDead  = zeros(1,T+1,'uint32');
accumD     = zeros(1,T+1,'uint32');
totalD1    = zeros(1,T+1,'uint32'); % incluye SD, SDH, SH, SUCI, SDD
totalU1    = zeros(1,T+1,'uint32'); % incluye SU, SUH, SUD
totalH1    = zeros(1,T+1,'uint32');
totalUCI1  = zeros(1,T+1,'uint32');
accumD1    = zeros(1,T+1,'uint32');
totalDead1 = zeros(1,T+1,'uint32');
totalD2    = zeros(1,T+1,'uint32'); % incluye SD, SDH, SH, SUCI, SDD
totalU2    = zeros(1,T+1,'uint32'); % incluye SU, SUH, SUD
totalH2    = zeros(1,T+1,'uint32');
totalUCI2  = zeros(1,T+1,'uint32');
totalDead2 = zeros(1,T+1,'uint32');
accumD2    = zeros(1,T+1,'uint32');
totalD3    = zeros(1,T+1,'uint32'); % incluye SD, SDH, SH, SUCI, SDD
totalU3    = zeros(1,T+1,'uint32'); % incluye SU, SUH, SUD
totalH3    = zeros(1,T+1,'uint32');
totalUCI3  = zeros(1,T+1,'uint32');
totalDead3 = zeros(1,T+1,'uint32');
accumD3    = zeros(1,T+1,'uint32');

% info per county per day
dataMap = nan(81,T);
dataMapAcum = zeros(81,T);
dataMapUCI = zeros(81,T);
dataMapH = zeros(81,T);
dataMapMuertes = zeros(81,T);
dataMapU = zeros(81,T);

% record time of last change of comparment
% eventualmente hacer uno solo, tomar index de compartimento activo
timeCompartmentE    = uint32(Inf(1,N));
timeCompartmentD    = uint32(Inf(1,N));
timeCompartmentDH   = uint32(Inf(1,N));
timeCompartmentDD   = uint32(Inf(1,N));
timeCompartmentU    = uint32(Inf(1,N));
timeCompartmentUH   = uint32(Inf(1,N));
timeCompartmentUD   = uint32(Inf(1,N));
timeCompartmentH    = uint32(Inf(1,N));
timeCompartmentUCI  = uint32(Inf(1,N));
%timeCompartmentR    = uint32(Inf(1,N));

% counties proximity (ordered by province)
nearCounties = computeNearCounties(trigger,direc);

% info for picking friends
selectPeople = cell(81,1);
for k = 1:81
    range = [];
    for j = nearCounties{k}
        newrange = cumsum_people_per_county(j)+1:cumsum_people_per_county(j+1);
        range = [range, newrange];
    end
    selectPeople{k} = uint32(range);
end

% alerta naranja
cantonesNaranja = xlsread([direc 'AlertaNaranja'],'AlertaNaranja','D3:EB83'); % ID de casos según MS

% read file with clusters
IDpaciente          = xlsread([direc nexosFile],nexosTab,'A2:A100000'); % ID de casos según MS
infectadoPor        = xlsread([direc nexosFile],nexosTab,'B2:B100000'); % quien infecta a ID; si es = es caso 0 del cluster
canton              = xlsread([direc nexosFile],nexosTab,'F2:F100000'); % cantón
grupoEtario         = xlsread([direc nexosFile],nexosTab,'I2:I100000'); % cantón
parentezco          = xlsread([direc nexosFile],nexosTab,'D2:D100000'); % parentezco: 1 2 3 4 5
[~,fechaDiagnost]   = xlsread([direc nexosFile],nexosTab,'H2:H100000'); % fecha diagóstico
fechaDiagnost       = datenum(datetime(fechaDiagnost,'InputFormat','MM/dd/yyyy'));

% create cell with neighbohrs (edges in the graph)
% 1: family, 2: known contacts 3: sporadic contacts
neighContacts = cell(N,3);

% sort dates with diagnostics
t1      = min(fechaDiagnost);
numDias = max(fechaDiagnost)-t1+1;

% number diagnosed pacients
numDiagnosticados = size(IDpaciente,1);

% diagnosed ID to graph ID
idDiagnosedToIdGraph = zeros(numDiagnosticados,1);

% level-one patients
level1Rows = find(IDpaciente==infectadoPor)';
% not level-one patients
notLevel1Rows = setdiffLoc(1:numDiagnosticados,level1Rows);

% three types of id: national, graph, diagnosed
% choose ID for level1 people (they have to be new nodes in the graph)
for row = level1Rows
    % current number case for D person
    idDiagnosed = IDpaciente(row);
    % choose person in county and check its family size
    population = cumsum_people_per_county(canton(row))+1:cumsum_people_per_county(canton(row)+1);
    currInd = population(randi(numel(population),1));
    %familySize = familyInfo(idToFamily(currInd));
    while(~notadded(currInd) || idToAge(currInd)~=grupoEtario(row))
        currInd = population(randi(numel(population),1));
    %    familySize = familyInfo(idToFamily(currInd));
    end
    % compute index in graph
    currIndGraph = numberNodesGraph+1;
    % update added nodes
    notadded(currInd) = false;
    % update graphID -> national ID
    GraphIDtoNationID(currIndGraph) = currInd;
    % update national ID -> graphID
    idToGraph(currInd) = currIndGraph;
    % update number nodes in G
    numberNodesGraph = currIndGraph;
    % update diagnosedID -> graphId
    idDiagnosedToIdGraph(idDiagnosed) = currIndGraph;
end
clear familyInfo

% choose ID for not level1 people (they have to be new nodes in the graph)
for row = notLevel1Rows
    % current number case for D person
    idDiagnosed = IDpaciente(row);
    % type of contact that infected current D person
    contactType = parentezco(row);
    % elegibles depend if they are family or not
    if(contactType == 1)
        nationalID_InfectedBy = GraphIDtoNationID(idDiagnosedToIdGraph(infectadoPor(row)));
        numFamily   = idToFamily(nationalID_InfectedBy);
        familyNodes = familyAccum(numFamily)+1:familyAccum(numFamily+1);
        elegibles   = setdiffLoc(familyNodes,nationalID_InfectedBy);
        % check node has not been added before 
        if(sum((idToAge(elegibles)==grupoEtario(row)).*notadded(elegibles)')==0) % all family has been added
            % pick a random person from the corresponding county
            population = cumsum_people_per_county(canton(row))+1:cumsum_people_per_county(canton(row)+1);
            currInd = population(randi(numel(population),1));            % check node has not been added before
            while(~notadded(currInd) || idToAge(currInd)~=grupoEtario(row))
                currInd = population(randi(numel(population),1));
            end
            storeContact = 2;
        else                            % there is at least one node to add with required age group
            index       = 1;
            currInd     =  elegibles(index);
            while(~notadded(currInd) || idToAge(currInd)~=grupoEtario(row))
                index   = index + 1;
                currInd = elegibles(index);
            end
            storeContact = 1;
        end
    else
        % pick a random person from the corresponding county
        population = cumsum_people_per_county(canton(row))+1:cumsum_people_per_county(canton(row)+1);
        currInd = population(randi(numel(population),1));            % check node has not been added before
        % check node has not been added before
        while(~notadded(currInd) || idToAge(currInd)~=grupoEtario(row))
            currInd = population(randi(numel(population),1));            % check node has not been added before
        end
        % decide if is known contact or sporadic
        if(contactType == 2 || contactType == 3)
            storeContact = 2;
        else
            storeContact = 3;
        end
    end
    % create connectivity with person that infected current D
    % compute index in graph
    currIndGraph = numberNodesGraph+1;
    % update added nodes
    notadded(currInd) = false;
    % update graphID -> national ID
    GraphIDtoNationID(currIndGraph) = currInd;
    % update national ID -> graphID
    idToGraph(currInd) = currIndGraph;
    % update number nodes in G
    numberNodesGraph = currIndGraph;
    % update diagnosedID -> graphId
    idDiagnosedToIdGraph(idDiagnosed) = currIndGraph;
    % include edges in graph
    neighContacts{idDiagnosedToIdGraph(infectadoPor(row)),storeContact}(end+1) = numberNodesGraph;
    neighContacts{numberNodesGraph,storeContact}(end+1) = idDiagnosedToIdGraph(infectadoPor(row));
end
clear contactType parentezco infectadoPor canton grupoEtario level1Rows notLevel1Rows

% all D in clusters
DiagnosedClass = GraphIDtoNationID(idDiagnosedToIdGraph(IDpaciente));

% create connectivity network for diagnosed id and its contacts
for row = 1:numDiagnosticados
    currIndGraph = idDiagnosedToIdGraph(IDpaciente(row));
    currInd      = GraphIDtoNationID(currIndGraph);
    % include family for new infected people; add if not in graph
    % find family and include new nodes for new found families
    numFamily   = idToFamily(currInd);
    if(~familyAdded(numFamily)) % check if family has been added before
        % ids for family
        familyNodes = familyAccum(numFamily)+1:familyAccum(numFamily+1);
        % remove nodes already in the graph
        nodesToAdd = familyNodes(notadded(familyNodes));
        % update added nodes
        notadded(nodesToAdd) = false;
        % update graphID -> national ID
        GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
        % update national ID -> graphID
        idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
        % update total number of nodes on graph
        numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
        % list all family edges (graph number of nodes)
        allEdges = combnk(idToGraph(familyNodes),2);
        % mark family as added
        familyAdded(numFamily)= true;
        % update neighborhs
        for m = 1:size(allEdges,1)
            neighContacts{allEdges(m,1),1}(end+1) = allEdges(m,2);
            neighContacts{allEdges(m,2),1}(end+1) = allEdges(m,1);
        end
    end
    
    % include known contacts
    newConnections = max(0,degreeContacts(currInd)-numel(neighContacts{currIndGraph,2}));
    if(newConnections>0)
        % who is eligible
        population = selectPeople{idToCounty(currInd)};
        elegiblesW = population(randi(numel(population),1,3*newConnections)); %nuevo
        elegiblesW = setdiffLoc(elegiblesW, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
        %if(numel(elegiblesW)<newConnections)
        %    warning('elegibles')
        %end
        newCoworkers = elegiblesW(randperm(numel(elegiblesW),newConnections));
        % find preexisting nodes on the graph
        nodesToAdd = newCoworkers(notadded(newCoworkers));
        % update added
        notadded(nodesToAdd) = false;
        % keep track of order of nodes
        GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
        idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
        numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
        % add edges
        allEdges = idToGraph(newCoworkers);
        % update neighborhs
        neighContacts{currIndGraph,2}(end+1:end+numel(allEdges)) = allEdges;
        for m = 1:numel(allEdges)
            neighContacts{allEdges(m),2}(end+1) = currIndGraph;
        end
    end
    
    % include sporadic contacts
    newConnections = max(0,degreeSporadic(currInd)-numel(neighContacts{currIndGraph,3}));
    if(newConnections>0)
        % who is eligible
        population = selectPeople{idToCounty(currInd)};
        elegiblesF = population(randi(numel(population),1,3*newConnections)); %nuevo
        elegiblesF = setdiffLoc(elegiblesF, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
        %if(numel(elegiblesF)<newConnections)
        %    warning('elegibles')
        %end
        newFriends   = elegiblesF(randperm(numel(elegiblesF),newConnections));
        % find preexisting nodes on the graph
        nodesToAdd = newFriends(notadded(newFriends));
        % update added
        notadded(nodesToAdd) = false;
        % keep track of order of nodes
        GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
        idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
        numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
        % add edges
        allEdges = idToGraph(newFriends);
        % update neighborhs
        neighContacts{currIndGraph,3}(end+1:end+numel(allEdges)) = allEdges;
        for m = 1:numel(allEdges)
            neighContacts{allEdges(m),3}(end+1) = currIndGraph;
        end
    end
end

for j = 1:numberNodesGraph % remove repetitions from first for
    neighContacts{j,1} = uniqueLoc(neighContacts{j,1});
    neighContacts{j,2} = uniqueLoc(neighContacts{j,2});
    neighContacts{j,3} = uniqueLoc(neighContacts{j,3});
end

% include exposed date (based on diagnosed date) and include U people
for time = 1:(numDias-testTime)
    % current day
    currentDay = t1 + time - 1;
    % find entries with current Day
    rows = ismember(fechaDiagnost,currentDay);
    % D people with current date
    indexGraph = idDiagnosedToIdGraph(IDpaciente(rows));
    indexD     = GraphIDtoNationID(indexGraph);
    % number of new U
    Dtoday = numel(indexD);
    % 75D-25U
    Utoday = floor(Dtoday*(1-RatioDiagnosedOverInfected)/RatioDiagnosedOverInfected);
    % randomly choose U from network
    if(Utoday>0)
        allNeigh = [];
        for k = indexGraph'
            allNeigh = [allNeigh, neighContacts{k,1}, neighContacts{k,2}, neighContacts{k,3}];
        end
        % people not in D
        allNeigh = setdiffLoc(allNeigh,idToGraph(DiagnosedClass));
        indexU = GraphIDtoNationID(allNeigh(randsample(numel(allNeigh),Utoday)));
        
        % include networks for U
        for k = indexU
            currInd      = k;%GraphIDtoNationID(currIndGraph);
            currIndGraph = idToGraph(currInd);%idDiagnosedToIdGraph(IDpaciente(row));
            % include family for new infected people; add if not in graph
            % find family and include new nodes for new found families
            numFamily   = idToFamily(currInd);
            if(~familyAdded(numFamily)) % check if family has been added before
                % ids for family
                familyNodes = familyAccum(numFamily)+1:familyAccum(numFamily+1);
                % remove nodes already in the graph
                nodesToAdd = familyNodes(notadded(familyNodes));
                % update added nodes
                notadded(nodesToAdd) = false;
                % update graphID -> national ID
                GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
                % update national ID -> graphID
                idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
                % update total number of nodes on graph
                numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
                % list all family edges (graph number of nodes)
                allEdges = combnk(idToGraph(familyNodes),2);
                % mark family as added
                familyAdded(numFamily)= true;
                % update neighborhs
                for m = 1:size(allEdges,1)
                    neighContacts{allEdges(m,1),1}(end+1) = allEdges(m,2);
                    neighContacts{allEdges(m,2),1}(end+1) = allEdges(m,1);
                end
            end
            
            % include known contacts
            newConnections = max(0,degreeContacts(currInd)-numel(neighContacts{currIndGraph,2}));
            if(newConnections>0)
                % who is eligible
                population = selectPeople{idToCounty(currInd)};
                elegiblesW = population(randi(numel(population),1,3*newConnections)); %nuevo
                elegiblesW = setdiffLoc(elegiblesW, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
                %if(numel(elegiblesW)<newConnections)
                %    warning('elegibles')
                %end
                newCoworkers = elegiblesW(randperm(numel(elegiblesW),newConnections));
                % find preexisting nodes on the graph
                nodesToAdd = newCoworkers(notadded(newCoworkers));
                % update added
                notadded(nodesToAdd) = false;
                % keep track of order of nodes
                GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
                idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
                numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
                % add edges
                allEdges = idToGraph(newCoworkers);
                % update neighborhs
                neighContacts{currIndGraph,2}(end+1:end+numel(allEdges)) = allEdges;
                for m = 1:numel(allEdges)
                    neighContacts{allEdges(m),2}(end+1) = currIndGraph;
                end
            end
            
            % include sporadic contacts
            newConnections = max(0,degreeSporadic(currInd)-numel(neighContacts{currIndGraph,3}));
            if(newConnections>0)
                % who is eligible
                population = selectPeople{idToCounty(currInd)};
                elegiblesF = population(randi(numel(population),1,3*newConnections)); %nuevo
                elegiblesF = setdiffLoc(elegiblesF, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
                %if(numel(elegiblesF)<newConnections)
                %    warning('elegibles')
                %end
                newFriends   = elegiblesF(randperm(numel(elegiblesF),newConnections));
                % find preexisting nodes on the graph
                nodesToAdd = newFriends(notadded(newFriends));
                % update added
                notadded(nodesToAdd) = false;
                % keep track of order of nodes
                GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
                idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
                numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
                % add edges
                allEdges = idToGraph(newFriends);
                % update neighborhs
                neighContacts{currIndGraph,3}(end+1:end+numel(allEdges)) = allEdges;
                for m = 1:numel(allEdges)
                    neighContacts{allEdges(m),3}(end+1) = currIndGraph;
                end
            end
        end
        timeCompartmentE(indexU) = currentDay - IncubationPeriod;
    end
    % store date for E
    timeCompartmentE(indexD) = currentDay - IncubationPeriod;
end

clear IDpaciente fechaDiagnost

% compute transitions for days related to cluster file
%t0 = datetime(datevec(t1-IncubationPeriod)); % first day in E class
%days = (t0:t0+T);         % range of days

% set dates for cases in the cluster file
for time = 1:(numDias-testTime)
    currentDay = t1 + time-1-IncubationPeriod;
    
    if(sum(SUCI)>UCIBeds_l3)
        PercUCIrecovers_G1 = PercUCIrecovers_sat3;
        PercUCIrecovers_G2 = PercUCIrecovers_sat3;
        PercUCIrecovers_G3 = PercUCIrecovers_sat3;
        %    elseif(sum(SUCI)>UCIBeds_l2)
        %        PercUCIrecovers = PercUCIrecovers_sat2;
        %    elseif(sum(SUCI)>UCIBeds_l1)
        %        PercUCIrecovers = PercUCIrecovers_sat1;
    else
        PercUCIrecovers_G1 = PercUCIrecovers0_G1;
        PercUCIrecovers_G2 = PercUCIrecovers0_G2;
        PercUCIrecovers_G3 = PercUCIrecovers0_G3;
    end
    
    if(sum(SH)>HBeds)
        PercHtoR_G1 = PercHtoR_sat;
        PercHtoR_G2 = PercHtoR_sat;
        PercHtoR_G3 = PercHtoR_sat;
    else
        PercHtoR_G1 = PercHtoR0_G1;
        PercHtoR_G2 = PercHtoR0_G2;
        PercHtoR_G3 = PercHtoR0_G3;
    end
    
    % S->E
    index = timeCompartmentE==currentDay;
    if(sum(index)>0)
        %if(sum(~SS(index))>0 ||sum(SE(index))>0)
        %    error('1')
        %end
        SS(index) = false;
        SE(index) = true;
    end
    
    % E -> D, E -> U
    index = currentDay-timeCompartmentE == IncubationPeriod;
    if(sum(index)>0)
        %if(sum(~SE(index))>0 ||sum(SD(index))>0 ||sum(SU(index))>0 ||sum(SDH(index))>0 ||sum(SUH(index))>0 ||sum(SDD(index))>0 ||sum(SUD(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        i1 = (ages==1).*(index);
        i1 = i1(i1>0);           % D and U
        i2 = (ages==2).*(index);
        i2 = i2(i2>0);           % D and U
        i3 = (ages==3).*(index);
        i3 = i3(i3>0);           % D and U
        indexD1 = intersect(DiagnosedClass,i1);
        indexD2 = intersect(DiagnosedClass,i2);
        indexD3 = intersect(DiagnosedClass,i3);
        indexU1 = setdiffLoc(i1,indexD1);
        indexU2 = setdiffLoc(i2,indexD2);
        indexU3 = setdiffLoc(i3,indexD3);
        requireHfromD1 = indexD1(logical(randsample(2,numel(indexD1),true,[1-PercDiagnosedToHospital_G1, PercDiagnosedToHospital_G1])-1)); % 1 if D will require H at day 4
        requireHfromD2 = indexD2(logical(randsample(2,numel(indexD2),true,[1-PercDiagnosedToHospital_G2, PercDiagnosedToHospital_G2])-1)); % 1 if D will require H at day 4
        requireHfromD3 = indexD3(logical(randsample(2,numel(indexD3),true,[1-PercDiagnosedToHospital_G3, PercDiagnosedToHospital_G3])-1)); % 1 if D will require H at day 4
        requireHfromU1 = indexU1(logical(randsample(2,numel(indexU1),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        requireHfromU2 = indexU2(logical(randsample(2,numel(indexU2),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        requireHfromU3 = indexU3(logical(randsample(2,numel(indexU3),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        willDiefromD1 = indexD1(logical(randsample(2,numel(indexD1),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromD2 = indexD2(logical(randsample(2,numel(indexD2),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromD3 = indexD3(logical(randsample(2,numel(indexD3),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromU1 = indexU1(logical(randsample(2,numel(indexU1),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromU2 = indexU2(logical(randsample(2,numel(indexU2),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromU3 = indexU3(logical(randsample(2,numel(indexU3),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromD1 = setdiffLoc(willDiefromD1,requireHfromD1);
        willDiefromD2 = setdiffLoc(willDiefromD2,requireHfromD2);
        willDiefromD3 = setdiffLoc(willDiefromD3,requireHfromD3);
        willDiefromU1 = setdiffLoc(willDiefromU1,requireHfromU1);
        willDiefromU2 = setdiffLoc(willDiefromU2,requireHfromU2);
        willDiefromU3 = setdiffLoc(willDiefromU3,requireHfromU3);
        noRequireHfromD1 = setdiffLoc(indexD1,[requireHfromD1 willDiefromD1]);
        noRequireHfromD2 = setdiffLoc(indexD2,[requireHfromD2 willDiefromD2]);
        noRequireHfromD3 = setdiffLoc(indexD3,[requireHfromD3 willDiefromD3]);
        noRequireHfromU1 = setdiffLoc(indexU1,[requireHfromU1 willDiefromU1]);
        noRequireHfromU2 = setdiffLoc(indexU2,[requireHfromU2 willDiefromU2]);
        noRequireHfromU3 = setdiffLoc(indexU3,[requireHfromU3 willDiefromU3]);
        noRequireHfromD = [noRequireHfromD1 noRequireHfromD2 noRequireHfromD3];
        noRequireHfromU = [noRequireHfromU1 noRequireHfromU2 noRequireHfromU3];
        requireHfromD   = [requireHfromD1 requireHfromD2 requireHfromD3];
        requireHfromU   = [requireHfromU1 requireHfromU2 requireHfromU3];
        willDiefromD    = [willDiefromD1 willDiefromD2 willDiefromD3];
        willDiefromU    = [willDiefromU1 willDiefromU2 willDiefromU3];
        % save changes compartiment
        SE(index)  = false;
        SD(noRequireHfromD) = true;
        SU(noRequireHfromU) = true;
        SDH(requireHfromD)  = true;
        SUH(requireHfromU)  = true;
        SDD(willDiefromD)   = true;
        SUD(willDiefromU)   = true;
        % save time
        timeCompartmentD(noRequireHfromD) = currentDay;
        timeCompartmentU(noRequireHfromU) = currentDay;
        timeCompartmentDH(requireHfromD)  = currentDay;
        timeCompartmentUH(requireHfromU)  = currentDay;
        timeCompartmentDD(willDiefromD)   = currentDay;
        timeCompartmentUD(willDiefromU)   = currentDay;
        indexD = [indexD1 indexD2 indexD3];
        %if(numel(index)~=numel(noRequireHfromD)+numel(noRequireHfromU)+...
        %        numel(requireHfromD)+numel(requireHfromU)+numel(willDiefromD)+...
        %        numel(willDiefromU))
        %    error('1')
        %end
    else % indexD is required to compute accumD
        indexD = [];
    end
    
    % check UH -> H
    index = currentDay-timeCompartmentUH == DaysUndiagnosedToHospital;
    if(sum(index)>0)
        %if(sum(~SUH(index))>0 ||sum(SH(index))>0)
        %    error('1')
        %end
        SUH(index) = false;
        SH(index) = true;
        timeCompartmentH(index) = currentDay;
    end
    
    % check DH -> H
    index = currentDay-timeCompartmentDH == DaysDiagnosedToHospital;
    if(sum(index)>0)
        %if(sum(~SDH(index))>0 ||sum(SH(index))>0)
        %    error('1')
        %end
        SDH(index) = false;
        SH(index) = true;
        timeCompartmentH(index) = currentDay;
    end
    
    index = currentDay-timeCompartmentUD == 10;
    if(sum(index)>0)
        %if(sum(~SUD(index))>0 ||sum(SDead(index))>0)
        %    error('1')
        %end
        SUD(index) = false;
        SDead(index) = true;
        %timeCompartmentH(index) = currentDay;
    end
    
    index = currentDay-timeCompartmentDD == 10;
    if(sum(index)>0)
        %if(sum(~SDD(index))>0 ||sum(SDead(index))>0)
        %    error('1')
        %end
        SDD(index) = false;
        SDead(index) = true;
        %timeCompartmentH(index) = currentDay;
    end

    if(time==108)
        DaysToRecoverDiagnosed     = 10;   % average time on D % antes estaba en 30
        DaysToRecoverUndiagnosed   = 10;   % average time on U % antes estaba en 30
    end
    
    % check for recoveries D -> R
    if(time==108)
        i1 = find(currentDay-timeCompartmentD == 17);
        i2 = find(currentDay-timeCompartmentD == 16);
        i3 = find(currentDay-timeCompartmentD == 15);
        i4 = find(currentDay-timeCompartmentD == 14);
        index = [i1 i2 i3 i4];
        SR(index) = true;
        SD(index) = false;
        %timeCompartmentR(index) = currentDay;
    else
        index = currentDay-timeCompartmentD == DaysToRecoverDiagnosed;
        %if(sum(~SD(index))>0 ||sum(SR(index))>0)
        %    error('1')
        %end
        SR(index) = true;
        SD(index) = false;
        %timeCompartmentR(index) = currentDay;
    end
    
    % check for recoveries U -> R
    if(time==108)
        i1 = find(currentDay-timeCompartmentU == 17);
        i2 = find(currentDay-timeCompartmentU == 16);
        i3 = find(currentDay-timeCompartmentU == 15);
        i4 = find(currentDay-timeCompartmentU == 14);
        index = [i1 i2 i3 i4];
        SR(index) = true;
        SU(index) = false;
        %timeCompartmentR(index) = currentDay;
    else
        index = currentDay-timeCompartmentU == DaysToRecoverUndiagnosed;
        %if(sum(~SU(index))>0 ||sum(SR(index))>0)
        %    error('1')
        %end
        SR(index) = true;
        SU(index) = false;
        %timeCompartmentR(index) = currentDay;
    end
    
    % check H -> UCI
    index = currentDay-timeCompartmentH == DaysHtoUCI;
    if(sum(index)>0)
        %if(sum(~SH(index))>0 ||sum(SUCI(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        i1 = (ages==1).*(index);
        i1 = i1(i1>0);           % D and U
        i2 = (ages==2).*(index);
        i2 = i2(i2>0);           % D and U
        i3 = (ages==3).*(index);
        i3 = i3(i3>0);           % D and U
        HtoUCI1 = i1(logical(randsample(2,numel(i1),true,[1-PercHtoUCI_G1, PercHtoUCI_G1])-1)); % 1 if goes to UCI
        HtoUCI2 = i2(logical(randsample(2,numel(i2),true,[1-PercHtoUCI_G2, PercHtoUCI_G2])-1)); % 1 if goes to UCI
        HtoUCI3 = i3(logical(randsample(2,numel(i3),true,[1-PercHtoUCI_G3, PercHtoUCI_G3])-1)); % 1 if goes to UCI
        HtoUCI = [HtoUCI1 HtoUCI2 HtoUCI3];
        SH(HtoUCI)   = false;
        SUCI(HtoUCI) = true;
        % save time
        timeCompartmentUCI(HtoUCI) = currentDay;
        timeCompartmentH(HtoUCI) = Inf;
        %if(numel(index)~=numel(HtoUCI))
        %    warning('1')
        %end
    end
    
    % check H -> R or dead
    index = currentDay-timeCompartmentH == DaysHospitalized_G1; % people with 14 days in H goes to R
    if(sum(index)>0)            % find people group age 1
        %if(sum(~SH(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);    % nationalID people with 14 days in H
        ages = idToAge(index);  % age of all people with 14 days in H
        index = (ages==1).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        HtoR = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G1, PercHtoR_G1])-1)); % 1 if recovers
        Hdies  = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        %timeCompartmentR(index) = currentDay;
        timeCompartmentH(index) = Inf;
        %if(numel(index)~= numel(HtoR)+numel(Hdies))
        %    error('1')
        %end
    end
    index = currentDay-timeCompartmentH == DaysHospitalized_G2; % people with 14 days in H goes to R
    if(sum(index)>0)            % find people group age 1
        %if(sum(~SH(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);    % nationalID people with 14 days in H
        ages = idToAge(index);  % age of all people with 14 days in H
        index = (ages==2).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        HtoR = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G2, PercHtoR_G2])-1)); % 1 if recovers
        Hdies  = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        %timeCompartmentR(index) = currentDay;
        timeCompartmentH(index) = Inf;
        %if(numel(index)~= numel(HtoR)+numel(Hdies))
        %    error('1')
        %end        
    end
    index = currentDay-timeCompartmentH == DaysHospitalized_G3; % people with 14 days in H goes to R
    if(sum(index)>0)            % find people group age 1
        %if(sum(~SH(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);    % nationalID people with 14 days in H
        ages = idToAge(index);  % age of all people with 14 days in H
        index = (ages==3).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        HtoR = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G3, PercHtoR_G3])-1)); % 1 if recovers
        Hdies  = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        %timeCompartmentR(index) = currentDay;
        timeCompartmentH(index) = Inf;
        %if(numel(index)~= numel(HtoR)+numel(Hdies))
        %    error('1')
        %end        
    end    
    
    % check UCI -> R or dead
    index = currentDay-timeCompartmentUCI == DaysUCI_G1;
    if(sum(index)>0)
        %if(sum(~SUCI(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        index = (ages==1).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        UCItoR = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G1, PercUCIrecovers_G1])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        %if(numel(index)~= numel(UCIdies)+numel(UCItoR))
        %    error('1')
        %end
    end
    index = currentDay-timeCompartmentUCI == DaysUCI_G2;
    if(sum(index)>0)
        %if(sum(~SUCI(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        index = (ages==2).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        UCItoR = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G2, PercUCIrecovers_G2])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        %if(numel(index)~= numel(UCIdies)+numel(UCItoR))
        %    error('1')
        %end
    end
    index = currentDay-timeCompartmentUCI == DaysUCI_G3;
    if(sum(index)>0)
        %if(sum(~SUCI(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        index = (ages==3).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        UCItoR = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G3, PercUCIrecovers_G3])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        %if(numel(index)~= numel(UCIdies)+numel(UCItoR))
        %    error('1')
        %end        
    end
    
    iu    = (SU==1|SUH==1|SUD==1)';
    id    = (SD==1|SDH==1|SDD==1)';
    ih    = (SH==1)';
    iuci  = (SUCI==1)';
    idead = (SDead==1)';
    % update
    totalH(time+1)    = sum(SH);
    totalUCI(time+1)  = sum(SUCI);
    totalD(time+1)    = sum(SD)+sum(SDH)+sum(SDD);
    totalU(time+1)    = sum(SU)+sum(SUH)+sum(SUD);
    totalDead(time+1) = sum(SDead);
    accumD(time+1)    = accumD(time) + numel(indexD);
    accumD1(time+1)   = accumD1(time) + sum(idToAge(indexD)==1);
    accumD2(time+1)   = accumD2(time) + sum(idToAge(indexD)==2);
    accumD3(time+1)   = accumD3(time) + sum(idToAge(indexD)==3);
    % salvar segun edad
    i1 = (idToAge==1);
    totalU1(time+1)    = sum(iu & i1);
    totalD1(time+1)    = sum(id & i1);
    totalH1(time+1)    = sum(ih & i1);
    totalUCI1(time+1)  = sum(iuci & i1);
    totalDead1(time+1) = sum(idead & i1);
    i1 = (idToAge==2);
    totalU2(time+1)    = sum(iu & i1);
    totalD2(time+1)    = sum(id & i1);
    totalH2(time+1)    = sum(ih & i1);
    totalUCI2(time+1)  = sum(iuci & i1);
    totalDead2(time+1) = sum(idead & i1);
    i1 = (idToAge==3);
    totalU3(time+1)    = sum(iu & i1);
    totalD3(time+1)    = sum(id & i1);
    totalH3(time+1)    = sum(ih & i1);
    totalUCI3(time+1)  = sum(iuci & i1);
    totalDead3(time+1) = sum(idead & i1);
    
    if(countyInfo)
        dataMap(:,time+1) = hist(idToCounty(logical(SD+SDH)),1:81); %#ok<*HIST,*UNRCH> % D
        del = hist(idToCounty(indexD),1:81)';
        dataMapAcum(:,time+1) = dataMapAcum(:,time)+del;
        % hospis y UCIs y muertes epor canton
        dataMapUCI(:,time+1) = hist(idToCounty(logical(SUCI)),1:81);
        dataMapH(:,time+1)   = hist(idToCounty(logical(SH)),1:81);
        dataMapMuertes(:,time+1) = hist(idToCounty(logical(SDead)),1:81);
        dataMapU(:,time+1)   = hist(idToCounty(logical(SU+SUH)),1:81);
    end
    %if(sum(SE)+sum(SD)+sum(SDH)+sum(SDD)+sum(SU)+sum(SUH)+sum(SUD)+sum(SR)+sum(SH)+sum(SUCI)+sum(SDead)-sum(~SS)~=0)
    %    error('transicion')
    %end
    %if(sum(SS)+sum(SE)+sum(SD)+sum(SDH)+sum(SDD)+sum(SU)+sum(SUH)+sum(SUD)+sum(SR)+sum(SH)+sum(SUCI)+sum(SDead)-N ~=0)
    %    error('transicion')
    %end
end

% add new infected for expanding the graph
newInfectedPeople = [];  % new Infected - national id
newInfectedGraph  = [];  % new Infected - graph id
possible = cat(2,neighContacts{idToGraph(SD+SU+SDH+SUH+SE>0),1:3});
useMask  = randsample(2,N,true,[1-pUseMask pUseMask])-1;
if(numel(possible)>0)
    possible = uniqueLoc(possible);
end
for j = possible         % check people that has contact with E,D,U
    currInd = GraphIDtoNationID(j);
    if(SS(currInd))       % if still susceptible might get sick
        region = canton2region(idToCounty(currInd));
        sizeBubble = minmaxBubble(region,1)+randi(minmaxBubble(region,2)-minmaxBubble(region,1)+1,1)-1;%minmaxBubble
        chosenN0 = GraphIDtoNationID(neighContacts{j,1});
        if(numel(neighContacts{j,2})+numel(neighContacts{j,3}) <= sizeBubble)
            chosenN1 = GraphIDtoNationID(neighContacts{j,2});
            chosenN2 = GraphIDtoNationID(neighContacts{j,3});
        else
            elegible   = cat(2,neighContacts{j,2:3});
            %if(numel(unique(elegible))~=numel(neighContacts{j,2})+numel(neighContacts{j,3}))
            %    warning('amigos')
            %end
            chosenN = randsample(elegible,sizeBubble);
            chosenN1 = GraphIDtoNationID(intersect(neighContacts{j,2},chosenN));
            chosenN2 = GraphIDtoNationID(intersect(neighContacts{j,3},chosenN));
        end
        % revisar estado naranja, para quitar los que no son del cantón
        if(cantonesNaranja(idToCounty(currInd),time-96)==1) % 18 agosto
            pUseDist = .55;
        else
            pUseDist = .45;
        end
        %useDist = zeros(N,1);
        useDist1 = randsample(2,numel(chosenN1),true,[1-pUseDist pUseDist])-1;
        useDist2 = randsample(2,numel(chosenN2),true,[1-pUseDist pUseDist])-1;
        % prob no infectarse por contactos de familia
        p1 = sum(SE(chosenN0)) + sum(SU(chosenN0)) + sum(SUH(chosenN0)) + coefDiagnosedContact*sum(SD(chosenN0)) + coefDiagnosedContact*sum(SDH(chosenN0));
        risk = (1-coefFam*p).^(coefMin*p1);
        % prob no infectarse por contactos conocidos
        p4 = chosenN1(logical(useMask(chosenN1).*useDist1)); % gente de chosenN1 que usan ambas
        p2 = setdiffLoc(chosenN1(logical(useMask(chosenN1))),p4); % gente de chosenN1 que usan solo mascarilla
        p3 = setdiffLoc(chosenN1(logical(useDist1)),p4); % gente de chosenN1 que usan solo distanciamiento
        p5 = setdiffLoc(chosenN1,[p2 p3 p4]);
        risk = risk*(1-coefMasc).^(coefMin*numel(p2))*(1-coefDist).^(coefMin*numel(p3))*(1-coefMD).^(coefMin*numel(p4))*(1-p).^(coefMin*numel(p5));
        % prob no infectarse por esporádicos
        p4 = chosenN2(logical(useMask(chosenN2).*useDist2)); % gente de chosenN1 que usan ambas
        p2 = setdiffLoc(chosenN2(logical(useMask(chosenN2))),p4); % gente de chosenN1 que usan solo mascarilla
        p3 = setdiffLoc(chosenN2(logical(useDist2)),p4); % gente de chosenN1 que usan solo distanciamiento
        p5 = setdiffLoc(chosenN2,[p2 p3 p4]);                
        risk = risk*(1-coefSpor*coefMasc).^(coefMin*numel(p2))*(1-coefSpor*coefDist).^(coefMin*numel(p3))*(1-coefSpor*coefMD).^(coefMin*numel(p4))*(1-coefSpor*p).^(coefMin*numel(p5));
        % prob infección
        risk = 1 - risk;
        infected = randsample(2,1,true,[1-risk, risk])-1;
        if(infected)
            newInfectedPeople = [newInfectedPeople, currInd]; %#ok<*AGROW>
            newInfectedGraph =  [newInfectedGraph, j];
        end
    end
end
initInfectedPeople = newInfectedPeople;
initInfectedGraph = newInfectedGraph;

clear DiagnosedClass


%%%%%%%%%%%%
% proyecciones
pUseDist = (40+10*rand(1))/100;
for time = (numDias-testTime+1):T % numDias = 137
    
    currentDay = t1 + time-1-IncubationPeriod;
    
    
    if(sum(SUCI)>UCIBeds_l3)
        %PercUCIrecovers = PercUCIrecovers_sat3;
        PercUCIrecovers_G1 = PercUCIrecovers_sat3;
        PercUCIrecovers_G2 = PercUCIrecovers_sat3;
        PercUCIrecovers_G3 = PercUCIrecovers_sat3;
        %    elseif(sum(SUCI)>UCIBeds_l2)
        %        PercUCIrecovers = PercUCIrecovers_sat2;
        %    elseif(sum(SUCI)>UCIBeds_l1)
        %        PercUCIrecovers = PercUCIrecovers_sat1;
    else
        PercUCIrecovers_G1 = PercUCIrecovers0_G1;
        PercUCIrecovers_G2 = PercUCIrecovers0_G2;
        PercUCIrecovers_G3 = PercUCIrecovers0_G3;
    end
    
    if(sum(SH)>HBeds)
        PercHtoR_G1 = PercHtoR_sat;
        PercHtoR_G2 = PercHtoR_sat;
        PercHtoR_G3 = PercHtoR_sat;
    else
        PercHtoR_G1 = PercHtoR0_G1;
        PercHtoR_G2 = PercHtoR0_G2;
        PercHtoR_G3 = PercHtoR0_G3;
    end
        
    % number of new infected people so we include all of its contacts
    n = numel(initInfectedPeople);
    % Update graph with new people
    for j = 1:n
        % Step 1: include family for new infecteded people; add if not in graph
        % current individual
        currInd = initInfectedPeople(j);     % global id
        currIndGraph = initInfectedGraph(j);  % local id
        % find family and include new nodes for new found families
        numFamily   = idToFamily(currInd);
        if(~familyAdded(numFamily))
            % ids for family
            familyNodes = familyAccum(numFamily)+1:familyAccum(numFamily+1);
            % remove nodes already in the graph
            nodesToAdd = familyNodes(notadded(familyNodes));
            % update added
            notadded(nodesToAdd) = false;
            GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
            idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
            numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
            % list all family edges (graph number of nodes)
            allEdges = combnk(idToGraph(familyNodes),2);
            % mark family as added
            familyAdded(numFamily)= true;
            % update neighborhs
            for m = 1:size(allEdges,1)
                neighContacts{allEdges(m,1),1}(end+1) = allEdges(m,2);
                neighContacts{allEdges(m,2),1}(end+1) = allEdges(m,1);
            end
        end
        
        % STEP 3: include known contacts
        % determine number of new connections
        newConnections = max(0,degreeContacts(currInd)-numel(neighContacts{currIndGraph,2}));
        if(newConnections>0)
            % who is eligible
            %elegiblesW = pickCoworkers(3*newConnections,cumsum_people_per_county,nearCounties{idToCounty(currInd)},density_per_county);
            population = selectPeople{idToCounty(currInd)};
            elegiblesW = population(randi(numel(population),1,3*newConnections)); %nuevo
            elegiblesW = setdiffLoc(elegiblesW, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
            %if(numel(elegiblesW)<newConnections)
            %    warning('elegibles')
            %end
            newCoworkers = elegiblesW(randperm(numel(elegiblesW),newConnections));
            % find preexisting nodes on the graph
            nodesToAdd = newCoworkers(notadded(newCoworkers));
            % update added
            notadded(nodesToAdd) = false;
            % keep track of order of nodes
            GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
            idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
            numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
            % add edges
            allEdges = idToGraph(newCoworkers);
            % update neighborhs
            neighContacts{currIndGraph,2}(end+1:end+numel(allEdges)) = allEdges;
            for m = 1:numel(allEdges)
                neighContacts{allEdges(m),2}(end+1) = currIndGraph;
            end
        end
        
        % STEP 4: include sporadic contacts
        % number of sporadic contacts
        newConnections = max(0,degreeSporadic(currInd)-numel(neighContacts{currIndGraph,3})); %countContacts(row,5);
        if(newConnections>0)
            % who is eligible
            %elegiblesF = pickCoworkers(3*newConnections,cumsum_people_per_county,nearCounties{idToCounty(currInd)},density_per_county);
            population = selectPeople{idToCounty(currInd)};
            elegiblesF = population(randi(numel(population),1,3*newConnections)); %nuevo
            elegiblesF = setdiffLoc(elegiblesF, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
            %if(numel(elegiblesF)<newConnections)
            %    warning('elegibles')
            %end
            newFriends   = elegiblesF(randperm(numel(elegiblesF),newConnections));
            % find preexisting nodes on the graph
            nodesToAdd = newFriends(notadded(newFriends));
            % update added
            notadded(nodesToAdd) = false;
            % keep track of order of nodes
            GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
            idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
            numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
            % add edges
            allEdges = idToGraph(newFriends);
            % update neighborhs
            neighContacts{currIndGraph,3}(end+1:end+numel(allEdges)) = allEdges;
            for m = 1:numel(allEdges)
                neighContacts{allEdges(m),3}(end+1) = currIndGraph;
            end
        end
    end
    
    % Transmit disease
    newInfectedPeople = [];  % new Infected - national id
    newInfectedGraph  = [];  % new Infected - graph id
    possible = cat(2,neighContacts{idToGraph(SD+SU+SDH+SUH+SE>0),1:3});
    useMask  = randsample(2,N,true,[1-pUseMask pUseMask])-1;
    if(numel(possible)>0)
        possible = uniqueLoc(possible);
    end
    if(mod(time,7)==1) % VIERNES
        pUseDist = (40+10*rand(1))/100;
    end
    if(mod(time,7)==4) % LUNES
        pUseDist = (50+10*rand(1))/100;
    end
    for j = possible         % check people that has contact with E,D,U
        currInd = GraphIDtoNationID(j);
        if(SS(currInd))       % if still susceptible might get sick
            region = canton2region(idToCounty(currInd));
            sizeBubble = minmaxBubble(region,1)+randi(minmaxBubble(region,2)-minmaxBubble(region,1)+1,1)-1;%minmaxBubble
            %elegible   = uniqueLoc(cat(2,neighContacts{j,2:3}));
            %numN = min(numel(elegible),sizeBubble);
            %if(numel(elegible)>1)
            %    chosenN = randsample(elegible,numN);
            %elseif(numel(elegible)==1)
            %    chosenN = elegible;
            %else
            %    chosenN = [];
            %end
            chosenN0 = GraphIDtoNationID(neighContacts{j,1});
            if(numel(neighContacts{j,2})+numel(neighContacts{j,3}) <= sizeBubble)
                chosenN1 = GraphIDtoNationID(neighContacts{j,2});
                chosenN2 = GraphIDtoNationID(neighContacts{j,3});
            else
                elegible   = cat(2,neighContacts{j,2:3});
                %if(numel(unique(elegible))~=numel(neighContacts{j,2})+numel(neighContacts{j,3}))
                %    warning('amigos')
                %end
                chosenN = randsample(elegible,sizeBubble);
                chosenN1 = GraphIDtoNationID(intersect(neighContacts{j,2},chosenN));
                chosenN2 = GraphIDtoNationID(intersect(neighContacts{j,3},chosenN));
            end
            % distribution for people that use mask and apply social distancing
            useDist1 = randsample(2,numel(chosenN1),true,[1-pUseDist pUseDist])-1;
            useDist2 = randsample(2,numel(chosenN2),true,[1-pUseDist pUseDist])-1;
            % prob no infectarse por contactos de familia
            p1 = sum(SE(chosenN0)) + sum(SU(chosenN0)) + sum(SUH(chosenN0)) + coefDiagnosedContact*sum(SD(chosenN0)) + coefDiagnosedContact*sum(SDH(chosenN0));
            risk = (1-coefFam*p).^(coefMin*p1);
            % prob no infectarse por contactos conocidos
            p4 = chosenN1(logical(useMask(chosenN1).*useDist1)); % gente de chosenN1 que usan ambas
            p2 = setdiffLoc(chosenN1(logical(useMask(chosenN1))),p4); % gente de chosenN1 que usan solo mascarilla
            p3 = setdiffLoc(chosenN1(logical(useDist1)),p4); % gente de chosenN1 que usan solo distanciamiento
            p5 = setdiffLoc(chosenN1,[p2 p3 p4]);
            risk = risk*(1-coefMasc).^(coefMin*numel(p2))*(1-coefDist).^(coefMin*numel(p3))*(1-coefMD).^(coefMin*numel(p4))*(1-p).^(coefMin*numel(p5));
            % prob no infectarse por esporádicos
            p4 = chosenN2(logical(useMask(chosenN2).*useDist2)); % gente de chosenN1 que usan ambas
            p2 = setdiffLoc(chosenN2(logical(useMask(chosenN2))),p4); % gente de chosenN1 que usan solo mascarilla
            p3 = setdiffLoc(chosenN2(logical(useDist2)),p4); % gente de chosenN1 que usan solo distanciamiento
            p5 = setdiffLoc(chosenN2,[p2 p3 p4]);
            risk = risk*(1-coefSpor*coefMasc).^(coefMin*numel(p2))*(1-coefSpor*coefDist).^(coefMin*numel(p3))*(1-coefSpor*coefMD).^(coefMin*numel(p4))*(1-coefSpor*p).^(coefMin*numel(p5));
            % prob infección
            risk = 1 - risk;
            infected = randsample(2,1,true,[1-risk, risk])-1;
            if(infected)
                newInfectedPeople = [newInfectedPeople, currInd]; %#ok<*AGROW>
                newInfectedGraph =  [newInfectedGraph, j];
            end
        end
    end
    
    % new S->E
    %if(sum(~SS(newInfectedPeople))>0 ||sum(SE(newInfectedPeople))>0)
    %    error('1')
    %end
    SS(newInfectedPeople) = false;
    SE(newInfectedPeople) = true;
    % save time so they can recover eventually
    timeCompartmentE(newInfectedPeople) = currentDay;
    
    % E -> D, E -> U
    index = currentDay-timeCompartmentE == IncubationPeriod;
    if(sum(index)>0)
        %if(sum(~SE(index))>0 ||sum(SD(index))>0 ||sum(SU(index))>0 ||sum(SDH(index))>0 ||sum(SUH(index))>0 ||sum(SDD(index))>0 ||sum(SUD(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        i1 = (ages==1).*(index);
        i1 = i1(i1>0);           % D and U
        i2 = (ages==2).*(index);
        i2 = i2(i2>0);           % D and U
        i3 = (ages==3).*(index);
        i3 = i3(i3>0);           % D and U
        randOrder = randperm(numel(i1));
        splitPosition = ceil(numel(i1)*RatioDiagnosedOverInfected);
        indexD1 = i1(randOrder(1:splitPosition));%intersect(DiagnosedClass,i1);
        indexU1 = i1(randOrder(splitPosition+1:end));%intersect(DiagnosedClass,i2);
        randOrder = randperm(numel(i2));
        splitPosition = ceil(numel(i2)*RatioDiagnosedOverInfected);
        indexD2 = i2(randOrder(1:splitPosition));%intersect(DiagnosedClass,i1);
        indexU2 = i2(randOrder(splitPosition+1:end));%intersect(DiagnosedClass,i2);
        randOrder = randperm(numel(i3));
        splitPosition = ceil(numel(i3)*RatioDiagnosedOverInfected); 
        indexD3 = i3(randOrder(1:splitPosition));%intersect(DiagnosedClass,i1);
        indexU3 = i3(randOrder(splitPosition+1:end));%intersect(DiagnosedClass,i2);
        requireHfromD1 = indexD1(logical(randsample(2,numel(indexD1),true,[1-PercDiagnosedToHospital_G1, PercDiagnosedToHospital_G1])-1)); % 1 if D will require H at day 4
        requireHfromD2 = indexD2(logical(randsample(2,numel(indexD2),true,[1-PercDiagnosedToHospital_G2, PercDiagnosedToHospital_G2])-1)); % 1 if D will require H at day 4
        requireHfromD3 = indexD3(logical(randsample(2,numel(indexD3),true,[1-PercDiagnosedToHospital_G3, PercDiagnosedToHospital_G3])-1)); % 1 if D will require H at day 4
        requireHfromU1 = indexU1(logical(randsample(2,numel(indexU1),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        requireHfromU2 = indexU2(logical(randsample(2,numel(indexU2),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        requireHfromU3 = indexU3(logical(randsample(2,numel(indexU3),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        willDiefromD1 = indexD1(logical(randsample(2,numel(indexD1),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromD2 = indexD2(logical(randsample(2,numel(indexD2),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromD3 = indexD3(logical(randsample(2,numel(indexD3),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromU1 = indexU1(logical(randsample(2,numel(indexU1),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromU2 = indexU2(logical(randsample(2,numel(indexU2),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromU3 = indexU3(logical(randsample(2,numel(indexU3),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromD1 = setdiffLoc(willDiefromD1,requireHfromD1);
        willDiefromD2 = setdiffLoc(willDiefromD2,requireHfromD2);
        willDiefromD3 = setdiffLoc(willDiefromD3,requireHfromD3);
        willDiefromU1 = setdiffLoc(willDiefromU1,requireHfromU1);
        willDiefromU2 = setdiffLoc(willDiefromU2,requireHfromU2);
        willDiefromU3 = setdiffLoc(willDiefromU3,requireHfromU3);
        noRequireHfromD1 = setdiffLoc(indexD1,[requireHfromD1 willDiefromD1]);
        noRequireHfromD2 = setdiffLoc(indexD2,[requireHfromD2 willDiefromD2]);
        noRequireHfromD3 = setdiffLoc(indexD3,[requireHfromD3 willDiefromD3]);
        noRequireHfromU1 = setdiffLoc(indexU1,[requireHfromU1 willDiefromU1]);
        noRequireHfromU2 = setdiffLoc(indexU2,[requireHfromU2 willDiefromU2]);
        noRequireHfromU3 = setdiffLoc(indexU3,[requireHfromU3 willDiefromU3]);
        noRequireHfromD = [noRequireHfromD1 noRequireHfromD2 noRequireHfromD3];
        noRequireHfromU = [noRequireHfromU1 noRequireHfromU2 noRequireHfromU3];
        requireHfromD   = [requireHfromD1 requireHfromD2 requireHfromD3];
        requireHfromU   = [requireHfromU1 requireHfromU2 requireHfromU3];
        willDiefromD    = [willDiefromD1 willDiefromD2 willDiefromD3];
        willDiefromU    = [willDiefromU1 willDiefromU2 willDiefromU3];
        % save changes compartiment
        SE(index)  = false;
        SD(noRequireHfromD) = true;
        SU(noRequireHfromU) = true;
        SDH(requireHfromD)  = true;
        SUH(requireHfromU)  = true;
        SDD(willDiefromD)   = true;
        SUD(willDiefromU)   = true;
        % save time
        timeCompartmentD(noRequireHfromD) = currentDay;
        timeCompartmentU(noRequireHfromU) = currentDay;
        timeCompartmentDH(requireHfromD)  = currentDay;
        timeCompartmentUH(requireHfromU)  = currentDay;
        timeCompartmentDD(willDiefromD)   = currentDay;
        timeCompartmentUD(willDiefromU)   = currentDay;
        indexD = [indexD1 indexD2 indexD3];
        %if(numel(index)~=numel(noRequireHfromD)+numel(noRequireHfromU)+...
        %        numel(requireHfromD)+numel(requireHfromU)+numel(willDiefromD)+...
        %        numel(willDiefromU))
        %    error('1')
        %end        
    else
        indexD = []; % to compute accumD
    end
    
    % check UH -> H
    index = currentDay-timeCompartmentUH == DaysUndiagnosedToHospital;
    if(sum(index)>0)
        %if(sum(~SUH(index))>0 ||sum(SH(index))>0)
        %    error('1')
        %end
        SUH(index) = false;
        SH(index) = true;
        timeCompartmentH(index) = currentDay;
    end
    
    % check DH -> H
    index = currentDay-timeCompartmentDH == DaysDiagnosedToHospital;
    if(sum(index)>0)
        %if(sum(~SDH(index))>0 ||sum(SH(index))>0)
        %    error('1')
        %end
        SDH(index) = false;
        SH(index) = true;
        timeCompartmentH(index) = currentDay;
    end
    
    index = currentDay-timeCompartmentUD == 10;
    if(sum(index)>0)
        %if(sum(~SUD(index))>0 ||sum(SDead(index))>0)
        %    error('1')
        %end
        SUD(index) = false;
        SDead(index) = true;
        %timeCompartmentH(index) = currentDay;
    end
    
    index = currentDay-timeCompartmentDD == 10;
    if(sum(index)>0)
        %if(sum(~SDD(index))>0 ||sum(SDead(index))>0)
        %    error('1')
        %end
        SDD(index) = false;
        SDead(index) = true;
        %timeCompartmentH(index) = currentDay;
    end
    
    % check for recoveries D -> R
    index = currentDay-timeCompartmentD == DaysToRecoverDiagnosed;
    %if(sum(~SD(index))>0 ||sum(SR(index))>0)
    %    error('1')
    %end
    SR(index) = true;
    SD(index) = false;
    %timeCompartmentR(index) = currentDay;
    
    % check for recoveries U -> R
    index = currentDay-timeCompartmentU == DaysToRecoverUndiagnosed;
    %if(sum(~SU(index))>0 ||sum(SR(index))>0)
    %    error('1')
    %end
    SR(index) = true;
    SU(index) = false;
    %timeCompartmentR(index) = currentDay;
    
    % check H -> UCI
    index = currentDay-timeCompartmentH == DaysHtoUCI;
    if(sum(index)>0)
        %if(sum(~SH(index))>0 ||sum(SUCI(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        i1 = (ages==1).*(index);
        i1 = i1(i1>0);           % D and U
        i2 = (ages==2).*(index);
        i2 = i2(i2>0);           % D and U
        i3 = (ages==3).*(index);
        i3 = i3(i3>0);           % D and U
        HtoUCI1 = i1(logical(randsample(2,numel(i1),true,[1-PercHtoUCI_G1, PercHtoUCI_G1])-1)); % 1 if goes to UCI
        HtoUCI2 = i2(logical(randsample(2,numel(i2),true,[1-PercHtoUCI_G2, PercHtoUCI_G2])-1)); % 1 if goes to UCI
        HtoUCI3 = i3(logical(randsample(2,numel(i3),true,[1-PercHtoUCI_G3, PercHtoUCI_G3])-1)); % 1 if goes to UCI
        HtoUCI = [HtoUCI1 HtoUCI2 HtoUCI3];
        SH(HtoUCI)   = false;
        SUCI(HtoUCI) = true;
        % save time
        timeCompartmentUCI(HtoUCI) = currentDay;
        timeCompartmentH(HtoUCI) = Inf;
        %if(numel(index)~=numel(HtoUCI))
        %    warning('1')
        %end
    end
    
    % check H -> R or dead
    index = currentDay-timeCompartmentH == DaysHospitalized_G1; % people with 14 days in H goes to R
    if(sum(index)>0)            % find people group age 1
        %if(sum(~SH(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);    % nationalID people with 14 days in H
        ages = idToAge(index);  % age of all people with 14 days in H
        index = (ages==1).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        HtoR = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G1, PercHtoR_G1])-1)); % 1 if recovers
        Hdies  = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        %timeCompartmentR(index) = currentDay;
        timeCompartmentH(index) = Inf;
        %if(numel(index)~= numel(HtoR)+numel(Hdies))
        %    error('1')
        %end
    end
    index = currentDay-timeCompartmentH == DaysHospitalized_G2; % people with 14 days in H goes to R
    if(sum(index)>0)            % find people group age 1
        %if(sum(~SH(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);    % nationalID people with 14 days in H
        ages = idToAge(index);  % age of all people with 14 days in H
        index = (ages==2).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        HtoR = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G2, PercHtoR_G2])-1)); % 1 if recovers
        Hdies  = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        %timeCompartmentR(index) = currentDay;
        timeCompartmentH(index) = Inf;
        %if(numel(index)~= numel(HtoR)+numel(Hdies))
        %    error('1')
        %end
    end
    index = currentDay-timeCompartmentH == DaysHospitalized_G3; % people with 14 days in H goes to R
    if(sum(index)>0)            % find people group age 1
        %if(sum(~SH(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);    % nationalID people with 14 days in H
        ages = idToAge(index);  % age of all people with 14 days in H
        index = (ages==3).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        HtoR = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G3, PercHtoR_G3])-1)); % 1 if recovers
        Hdies  = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        %timeCompartmentR(index) = currentDay;
        timeCompartmentH(index) = Inf;
        %if(numel(index)~= numel(HtoR)+numel(Hdies))
        %    error('1')
        %end
    end
    
    % check UCI -> R or dead
    index = currentDay-timeCompartmentUCI == DaysUCI_G1;
    if(sum(index)>0)
        %if(sum(~SUCI(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        index = (ages==1).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        UCItoR = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G1, PercUCIrecovers_G1])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        %if(numel(index)~= numel(UCIdies)+numel(UCItoR))
        %    error('1')
        %end
    end
    index = currentDay-timeCompartmentUCI == DaysUCI_G2;
    if(sum(index)>0)
        %if(sum(~SUCI(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        index = (ages==2).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        UCItoR = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G2, PercUCIrecovers_G2])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        %if(numel(index)~= numel(UCIdies)+numel(UCItoR))
        %    error('1')
        %end
    end
    index = currentDay-timeCompartmentUCI == DaysUCI_G3;
    if(sum(index)>0)
        %if(sum(~SUCI(index))>0 || sum(SR(index))>0 || sum(SDead(index))>0)
        %    error('1')
        %end
        index = find(index);
        ages = idToAge(index);
        index = (ages==3).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        UCItoR = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G3, PercUCIrecovers_G3])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        %if(numel(index)~= numel(UCIdies)+numel(UCItoR))
        %    error('1')
        %end
    end
    
    % update
    initInfectedPeople = newInfectedPeople;
    initInfectedGraph = newInfectedGraph;
    
    iu    = (SU==1|SUH==1|SUD==1)';
    id    = (SD==1|SDH==1|SDD==1)';
    ih    = (SH==1)';
    iuci  = (SUCI==1)';
    idead = (SDead==1)';
    % update
    totalH(time+1)    = sum(SH);
    totalUCI(time+1)  = sum(SUCI);
    totalD(time+1)    = sum(SD)+sum(SDH)+sum(SDD);
    totalU(time+1)    = sum(SU)+sum(SUH)+sum(SUD);
    totalDead(time+1) = sum(SDead);
    accumD(time+1)    = accumD(time) + numel(indexD);
    accumD1(time+1)   = accumD1(time) + sum(idToAge(indexD)==1);
    accumD2(time+1)   = accumD2(time) + sum(idToAge(indexD)==2);
    accumD3(time+1)   = accumD3(time) + sum(idToAge(indexD)==3);
    % salvar segun edad
    i1 = (idToAge==1);
    totalU1(time+1)    = sum(iu & i1);
    totalD1(time+1)    = sum(id & i1);
    totalH1(time+1)    = sum(ih & i1);
    totalUCI1(time+1)  = sum(iuci & i1);
    totalDead1(time+1) = sum(idead & i1);
    i1 = (idToAge==2);
    totalU2(time+1)    = sum(iu & i1);
    totalD2(time+1)    = sum(id & i1);
    totalH2(time+1)    = sum(ih & i1);
    totalUCI2(time+1)  = sum(iuci & i1);
    totalDead2(time+1) = sum(idead & i1);
    i1 = (idToAge==3);
    totalU3(time+1)    = sum(iu & i1);
    totalD3(time+1)    = sum(id & i1);
    totalH3(time+1)    = sum(ih & i1);
    totalUCI3(time+1)  = sum(iuci & i1);
    totalDead3(time+1) = sum(idead & i1);
        
    if(countyInfo)
        dataMap(:,time) = hist(idToCounty(logical(SD+SDH)),1:81); % D
        del = hist(idToCounty(indexD),1:81)';
        dataMapAcum(:,time+1) = dataMapAcum(:,time)+del;
        % hospis y UCIs y muertes epor canton
        dataMapUCI(:,time+1) = hist(idToCounty(logical(SUCI)),1:81);
        dataMapH(:,time+1)   = hist(idToCounty(logical(SH)),1:81);
        dataMapMuertes(:,time+1) = hist(idToCounty(logical(SDead)),1:81);
        dataMapU(:,time+1)   = hist(idToCounty(logical(SU+SUH)),1:81);
    end
    
    %disp([time (totalH(time+1)-totalH(time)) (totalUCI(time+1)-totalUCI(time))])
end

toc

export = zeros(T+1,24,'uint32');
export(:,1) = accumD;
export(:,2) = totalD;
export(:,3) = totalH;
export(:,4) = totalUCI;
export(:,5) = totalDead;
export(:,6) = totalU;
export(:,7) = totalD1;
export(:,8) = totalH1;
export(:,9) = totalUCI1;
export(:,10) = totalDead1;
export(:,11) = totalU1;
export(:,12) = totalD2;
export(:,13) = totalH2;
export(:,14) = totalUCI2;
export(:,15) = totalDead2;
export(:,16) = totalU2;
export(:,17) = totalD3;
export(:,18) = totalH3;
export(:,19) = totalUCI3;
export(:,20) = totalDead3;
export(:,21) = totalU3;
export(:,22) = accumD1;
export(:,23) = accumD2;
export(:,24) = accumD3;
end

function parsave(k,x,dir,nameFile)
 nameFile = [dir '/' nameFile num2str(k) '.mat'];
 save(nameFile, 'x')
end

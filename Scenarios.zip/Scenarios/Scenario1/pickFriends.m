function people = pickFriends(NFriends,countyId,cumsum_people_per_county)
    j = countyId;
    range = cumsum_people_per_county(j)+1:cumsum_people_per_county(j+1);
    people = randsample(range,NFriends);
end


%randsample(cumsum_people_per_county(j)+1:cumsum_people_per_county(j+1),NFriends);
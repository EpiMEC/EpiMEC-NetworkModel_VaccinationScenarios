function c = uniqueLoc(a)
if(numel(a)>0)
    a = a(:); % Convert to column
    isSortedA = issorted(a); % Sort A and get the indices if needed.
    if isSortedA
        sortA = a;
    else
        sortA = sort(a);
    end
    % groupsSortA indicates the location of non-matching entries.
    dSortA = diff(sortA);
    groupsSortA = dSortA ~= 0;
    groupsSortA = [true; groupsSortA];          % First element is always a member of unique list.
    c = sortA(groupsSortA);         % Create unique list by indexing into sorted list.
    
    % If A is row vector, return C as row vector.
    c = c.';
else
    c=a;
end
end
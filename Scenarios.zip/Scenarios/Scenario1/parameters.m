% Parameters
PercUndiagnosedToHospital  = .00;    %    1 % U se hospitalizan
PercDiagnosedToHospital_G1 = .022;   %  2.2 % D se hospitalizan - G1
PercDiagnosedToHospital_G2 = .047;   %  4.7 % D se hospitalizan - G2
PercDiagnosedToHospital_G3 = .371;   % 37.1 % D se hospitalizan - G3
PercHtoUCI_G1              = .13;    % 14 % H a UCI - G1
PercHtoUCI_G2              = .31;    % 27 % H a UCI - G2
PercHtoUCI_G3              = .34;    % 30 % H a UCI - G3
DaysDiagnosedToHospital    = 4;      % tiempo D a H
DaysUndiagnosedToHospital  = 4;      % tiempo U a H
DaysHtoUCI                 = 5;      % tiempo H a UCI
DaysUCI_G1                 = 4;      % tiempo en UCI - G1
DaysUCI_G2                 = 17;     % tiempo en UCI - G2
DaysUCI_G3                 = 15;     % tiempo en UCI - G3
DaysHospitalized_G1        = 9;      % tiempo en H - G1
DaysHospitalized_G2        = 10;      % tiempo en H - G1
DaysHospitalized_G3        = 15;     % tiempo en H - G1
PercHtoR0_G1               = 1.0;    %  98 % H a R - G1 (mortalidad 2%)
PercHtoR0_G2               = .96;    %  95 % H a R - G2 (mortalidad 4%)
PercHtoR0_G3               = .75;    %  90 % H a R - G3 (mortalidad 28%)
PercUCIrecovers0_G1        = 1.0;    % 100 % UCIs to R - G1 (mortalidad 0%)
PercUCIrecovers0_G2        = .78;    %  88 % UCIs to R - G1 (mortalidad 23%)
PercUCIrecovers0_G3        = .59;    %  76 % UCIs to R - G1 (mortalidad 44%)
PercDeathsDU               = 0.0008; % 0.08% mortalidad fuera de hospitalización
DaysToRecoverDiagnosed     = 17;     % tiempo promedio en D
DaysToRecoverUndiagnosed   = 17;     % tiempo promedio en U
DaysDeathH   = 6;
DaysDeathUCI = 6;
% en el código se cambia a 14 días del 13 de junio en adelante
RatioDiagnosedOverInfected = .75;    % 75 % pacientes se diagnostican
HBeds                      = 2216;
UCIBeds_l1                 = 67;     % umbrales cama UCI
UCIBeds_l2                 = 159;
UCIBeds_l3                 = 287;
coefDiagnosedContact       = .10;    % 10 % D no se pone en cuarentena
p                          = .21;    % tasa transmisión
IncubationPeriod           = 6;      % periodo de incubación
pUseMask                   = .70;    % 70 % usa mascarilla
% cambios mortalidad según edad?
PercUCIrecovers_sat1       = .60;  % 40 % mortalidad primer umbral
PercUCIrecovers_sat2       = .40;  % 60 % mortalidad primer umbral
PercUCIrecovers_sat3       = .10;  % 90 % mortalidad primer umbral
PercHtoR_sat               = .85;  % 85 % H a R (sin camas)
% tamaño contactos
min_coworkers     = 10;  % number coworkers: min_coworkers +
max_dev_coworkers = 10;   %              randi(max_dev_coworkers) - 1 %%%% ** need to add age, so we add workers just in some cases**
min_sporadic      = 0;   % number friends: min_friends +
max_dev_sporadic  = 20;   %              randi(max_dev_friends) - 1
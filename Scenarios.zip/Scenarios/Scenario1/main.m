%%%% Este escenario considera la probabilidad de infeccion, luego de la
%%%% vacuna, igual a cero.

T = 674;%171; % 171
coefMin  = 0.014;% I Sim .014

simulations   = 50;
direc     = './info/';
nameFile1 = 'proy_';
nameFile2 = 'mapAct_';
nameFile3 = 'mapAcum_';
nameFile4 = 'mapUCI_';
nameFile5 = 'mapH_';
nameFile6 = 'mapMuertes_';
nameFile7 = 'mapU_';

for sim =1:simulations
    [data, dataMap,dataMapAcum,...
        dataMapUCI,dataMapH,dataMapMuertes,dataMapU] = runV4(T,coefMin);
    parsave(sim,data,direc,nameFile1);
    parsave(sim,dataMap,direc,nameFile2);
    parsave(sim,dataMapAcum,direc,nameFile3);
    parsave(sim,dataMapUCI,direc,nameFile4);
    parsave(sim,dataMapH,direc,nameFile5);
    parsave(sim,dataMapMuertes,direc,nameFile6);
    parsave(sim,dataMapU,direc,nameFile7);
end

function [export,dataMap,dataMapAcum,...
    dataMapUCI,dataMapH,dataMapMuertes,dataMapU] = runV4(T,coefMin)

tic

% datos vacunas
infoVac = load('infoVac');
infoVac = infoVac.infoVac;
infoVac(:,1) = infoVac(:,1)+1;
% Definition of variables
direc     = './info/';
nexosFile = 'Nexos16';
nexosTab  = 'Sheet 1';
%-----------------------------------------------------------------------
lesshosp   = 0.2; %reduccion de hospitalizacion
lessinf1   = 0.37; %Reduccion en infección primera dosis (63%)
lessinf2   = 0.10; %Reduccion en infección segunda dosis (90%)

porcNoVacunadosE1 = .0;
porcNoVacunadosE2 = .30;
porcNoVacunadosE3 = .10;

%------------------------------------------------------------------------

PercUndiagnosedToHospital  = .00;     %    1 % U se hospitalizan
PercDiagnosedToHospital_G1 = .0182;   %  2.2 % D se hospitalizan - G1
PercDiagnosedToHospital_G2 = .0368;   %  4.7 % D se hospitalizan - G2
PercDiagnosedToHospital_G3 = 0.31;%.3753;   % 37.1 % D se hospitalizan - G3
DaysDiagnosedToHospital    = 5;             % tiempo D a H

PercDiagnosedToHospital_G1_V = .0;              %JG0622
PercDiagnosedToHospital_G2_V = .0368*lesshosp;  %JG0622
PercDiagnosedToHospital_G3_V =  0.31*lesshosp;  %JG0622

DaysHospitalized_G1        = 7;      % tiempo en H - G1
DaysHospitalized_G2        = 10;     % tiempo en H - G1
DaysHospitalized_G3        = 15;     % tiempo en H - G1

%------------------------------------------------------------------------
DaysHtoUCI                 = 6;       % tiempo H a UCI

DaysUCI_G1                 = 4;       %4 tiempo en UCI - G1
DaysUCI_G2                 = 14;      % tiempo en UCI - G2
DaysUCI_G3                 = 11;      % tiempo en UCI - G3

PercHtoUCI_G1              = .11;     % 14 % H a UCI - G1
PercHtoUCI_G2              = .336;    % 27 % H a UCI - G2
PercHtoUCI_G3              = .3316;   % 30 % H a UCI - G3

DaysUndiagnosedToHospital  = 5;      % tiempo U a H


PercHtoR_G1                = 1.0;    %  98 % H a R - G1 (mortalidad 2%)
PercHtoR_G2                = .955;    %  95 % H a R - G2 (mortalidad 4%)
PercHtoR_G3                = .777;    %  90 % H a R - G3 (mortalidad 28%)

PercUCIrecovers_G1         = 1.0;    % 100 % UCIs to R - G1 (mortalidad 0%)
PercUCIrecovers_G2         = .77;    %  88 % UCIs to R - G1 (mortalidad 23%)
PercUCIrecovers_G3         = .537;    %  76 % UCIs to R - G1 (mortalidad 44%)
PercDeathsDU               = 0.0008; % 0.08% mortalidad fuera de hospitalización
DaysToRecoverDiagnosed     = 10;     % tiempo promedio en D
DaysToRecoverUndiagnosed   = 14;     % tiempo promedio en U
% en el código se cambia a 14 días del 13 de junio en adelante
RatioDiagnosedOverInfected = .60;    % 75 % pacientes se diagnostican
coefDiagnosedContact       = .10;    % 10 % D no se pone en cuarentena
p                          = .21;    % tasa transmisión
pv1                        = .21*lessinf1;  % El 40% de la poblacion vacunada se puede infectar
pv2                        = .21*lessinf2; % El 5% de la poblacion vacunada se puede infectar
IncubationPeriod           =  6;      % periodo de incubación
pUseMask                   = randsample([0.65,0.70,0.75,0.80], 1);      %.65;    % 70 % usa mascarilla
num                        = randsample([40,45,50], 1);
pUseDist = (num+20*rand(81,1))/100;

%%%vaccination parameters--------------------------------------------------
%%%------------------------------------------------------------------------
TotalVacE1 = 598102;    % Total de personas a vacunar en el grupo E1
Lim1V2  = 0.4*4274344;  % 40% de la población objetivo vacunada
Lim2V2  = 0.6*4274344;  % 60% de la población objetivo vacunada

ImmunityTimeR      =  90;            %dias de inmunidad por infeccion (R->RR)
TimeSV             =  21;            %Dias para quedar removido de los susceptibles una vez recive la vacuna
DosesE1 =  0;                        %Dosis diarias niños
DosesE2 =  303;                      %Dosis diarias adultos
DosesE3 =  45;                       %Dosis diarias adulto mayor
vaccineTime        =  304;           %Fecha en la que se inicia la vacunacion (dic 24)

%%%-----------------------------------------------------------------------
% tamaño contactos
min_coworkers     = 10;  % number coworkers: min_coworkers +
max_dev_coworkers = 10;   %              randi(max_dev_coworkers) - 1 %%%% ** need to add age, so we add workers just in some cases**
min_sporadic      = 0;   % number friends: min_friends +
max_dev_sporadic  = 20;   %              randi(max_dev_friends) - 1
% options
countyInfo =  true;
testTime   =  5;
trigger    =  0.005; % more connectivity if smaller
coefFam    = .8;
coefMasc   = .0945;
coefDist   = .0420;
coefMD     = .0189; %(1-EM)(1-PD)
coefSpor   = .50;

canton2region = xlsread([direc '5Regiones'],'Regiones','F2:G82');
canton2region = sortrows(canton2region);
canton2region = canton2region(:,2);
minmaxBubble  = xlsread([direc '5Regiones'],'Regiones','K2:L6');

% demographic info
[familyInfo,idToCounty,idToFamily,~,...
    cumsum_people_per_county,idToAge,familyAccum] = start_family(direc);
familyAdded = false(numel(familyInfo),1); % true if family is already in graph
N = sum(familyInfo);                      % total population

% Preasign degree for each node
% coworkers: uniform value in [min_coworkers, min_coworkers+max_dev_coworkers-1]
degreeContacts = uint8(min_coworkers+randi(max_dev_coworkers,N,1)-1);
degreeSporadic = uint8(min_sporadic +randi(max_dev_sporadic, N,1)-1);

% "national id" on the graph
GraphIDtoNationID = zeros(1,N,'uint32'); % people id when included in graph
numberNodesGraph  = 0;                   % number of nodes on graph

% national id to local graph index
idToGraph = zeros(1,N,'uint32');

% keep track of added ids (so no need to use ismember)
notadded = true(N,1);

% compartmental states at time t
SS    = true(N,1);  % susceptible
SE    = false(N,1); % asymptomatic
SD    = false(N,1); % diagnosed (-> R)
SDH   = false(N,1); % diagnosed (-> H)
SDD   = false(N,1); % diagnosed (-> D)
SU    = false(N,1); % undiagnosed (-> R)
SUH   = false(N,1); % undiagnosed (-> H)
SUD   = false(N,1); % undiagnosed (-> D)
SR    = false(N,1); % recovered
SH    = false(N,1); % hospitalized
SUCI  = false(N,1); % intensive care unit
SDead = false(N,1); % dead patient
SV1   = false(N,1); % personas vacunadas pero aún susceptibles
SV2   = false(N,1); % personas vacunadas inmunes
RR    = false(N,1); % personas que tienen mas de tres meses infectadas.
Vac   = false(N,1); % personas con al menos una vacuna (para bajar D->H) %JG0622

%%%%%% %JG0809
e1 = find(idToAge == 1);
e2 = find(idToAge == 2);
e3 = find(idToAge == 3);
noSeVacunan = [randsample(e1,round(porcNoVacunadosE1*numel(e1))), randsample(e2,round(porcNoVacunadosE2*numel(e2))), randsample(e3,round(porcNoVacunadosE3*numel(e3)))];
%%%%%%%


% datos diarios (totales y por grupo etario) 
totalS     = zeros(1,T+1,'uint32');
totalE     = zeros(1,T+1,'uint32');
totalR     = zeros(1,T+1,'uint32');
totalRR    = zeros(1,T+1,'uint32');
totalD     = zeros(1,T+1,'uint32'); % incluye SD, SDH, SH, SUCI, SDD
totalU     = zeros(1,T+1,'uint32'); % incluye SU, SUH, SUD
totalH     = zeros(1,T+1,'uint32');
totalUCI   = zeros(1,T+1,'uint32');
totalDead  = zeros(1,T+1,'uint32');
totalV1    = zeros(1,T+1,'uint32');
totalV2    = zeros(1,T+1,'uint32');
accumD     = zeros(1,T+1,'uint32');
accumV1    = zeros(1,T+1,'uint32');
accumV1E1  = zeros(1,T+1,'uint32');
accumV1E2  = zeros(1,T+1,'uint32');
accumV1E3  = zeros(1,T+1,'uint32');
accumV2    = zeros(1,T+1,'uint32');
accumV2E1  = zeros(1,T+1,'uint32');
accumV2E2  = zeros(1,T+1,'uint32');
accumV2E3  = zeros(1,T+1,'uint32');
nuevosH1  = zeros(1,T+1,'uint32');  % JG0816
nuevosH2  = zeros(1,T+1,'uint32');  % JG0816
nuevosH3  = zeros(1,T+1,'uint32');  % JG0816
nuevosUCI1  = zeros(1,T+1,'uint32');% JG0816
nuevosUCI2  = zeros(1,T+1,'uint32');% JG0816
nuevosUCI3  = zeros(1,T+1,'uint32');% JG0816

totalD1    = zeros(1,T+1,'uint32'); % incluye SD, SDH, SH, SUCI, SDD
totalU1    = zeros(1,T+1,'uint32'); % incluye SU, SUH, SUD
totalH1    = zeros(1,T+1,'uint32');
totalUCI1  = zeros(1,T+1,'uint32');
accumD1    = zeros(1,T+1,'uint32');
totalV1E1  = zeros(1,T+1,'uint32');
totalV2E1  = zeros(1,T+1,'uint32');
totalDead1 = zeros(1,T+1,'uint32');

totalD2    = zeros(1,T+1,'uint32'); % incluye SD, SDH, SH, SUCI, SDD
totalU2    = zeros(1,T+1,'uint32'); % incluye SU, SUH, SUD
totalH2    = zeros(1,T+1,'uint32');
totalUCI2  = zeros(1,T+1,'uint32');
totalDead2 = zeros(1,T+1,'uint32');
totalV1E2  = zeros(1,T+1,'uint32');
totalV2E2  = zeros(1,T+1,'uint32');
accumD2    = zeros(1,T+1,'uint32');

totalD3    = zeros(1,T+1,'uint32'); % incluye SD, SDH, SH, SUCI, SDD
totalU3    = zeros(1,T+1,'uint32'); % incluye SU, SUH, SUD
totalH3    = zeros(1,T+1,'uint32');
totalUCI3  = zeros(1,T+1,'uint32');
totalDead3 = zeros(1,T+1,'uint32');
totalV1E3  = zeros(1,T+1,'uint32');
totalV2E3  = zeros(1,T+1,'uint32');
accumD3    = zeros(1,T+1,'uint32');

% info per county per day
dataMap        = nan(81,T);
dataMapAcum    = zeros(81,T);
dataMapUCI     = zeros(81,T);
dataMapH       = zeros(81,T);
dataMapMuertes = zeros(81,T);
dataMapU       = zeros(81,T);

% record time of last change of comparment
timeCompartmentE    = uint32(Inf(1,N));
timeCompartmentD    = uint32(Inf(1,N));
timeCompartmentDH   = uint32(Inf(1,N));
timeCompartmentDD   = uint32(Inf(1,N));
timeCompartmentU    = uint32(Inf(1,N));
timeCompartmentUH   = uint32(Inf(1,N));
timeCompartmentUD   = uint32(Inf(1,N));
timeCompartmentH    = uint32(Inf(1,N));
timeCompartmentUCI  = uint32(Inf(1,N));
timeCompartmentR    = uint32(Inf(1,N));
timeCompartmentV1   = uint32(Inf(1,N));
timeCompartmentV2   = uint32(Inf(1,N));

% counties proximity (ordered by province)
nearCounties = computeNearCounties(trigger,direc);

% info for picking friends
selectPeople = cell(81,1);
for k = 1:81
    range = [];
    for j = nearCounties{k}
        newrange = cumsum_people_per_county(j)+1:cumsum_people_per_county(j+1);
        range = [range, newrange];
    end
    selectPeople{k} = uint32(range);
end


% read file with clusters
IDpaciente          = xlsread([direc nexosFile],nexosTab,'A2:A361534'); % ID de casos según MS
infectadoPor        = xlsread([direc nexosFile],nexosTab,'B2:B361534'); % quien infecta a ID; si es = es caso 0 del cluster
canton              = xlsread([direc nexosFile],nexosTab,'F2:F361534'); % cantón
grupoEtario         = xlsread([direc nexosFile],nexosTab,'I2:I361534'); % cantón
parentezco          = xlsread([direc nexosFile],nexosTab,'D2:D361534'); % parentezco: 1 2 3 4 5
[~,fechaDiagnost]   = xlsread([direc nexosFile],nexosTab,'H2:H361534'); % fecha diagóstico
fechaDiagnost       = datenum(datetime(fechaDiagnost,'InputFormat','MM/dd/yyyy'));

% create cell with neighbohrs (edges in the graph)
% 1: family, 2: known contacts 3: sporadic contacts
neighContacts = cell(N,3);

% sort dates with diagnostics
t1      = min(fechaDiagnost);
numDias = max(fechaDiagnost)-t1+1;

% number diagnosed pacients
numDiagnosticados = size(IDpaciente,1);

% diagnosed ID to graph ID
idDiagnosedToIdGraph = zeros(numDiagnosticados,1);

% level-one patients
level1Rows = find(IDpaciente==infectadoPor)';
% not level-one patients
notLevel1Rows = setdiffLoc(1:numDiagnosticados,level1Rows);

% three types of id: national, graph, diagnosed
% choose ID for level1 people (they have to be new nodes in the graph)
for row = level1Rows
    % current number case for D person
    idDiagnosed = IDpaciente(row);
    % choose person in county and check its family size
    population = cumsum_people_per_county(canton(row))+1:cumsum_people_per_county(canton(row)+1);
    currInd = population(randi(numel(population),1));
    %familySize = familyInfo(idToFamily(currInd));
    while(~notadded(currInd) || idToAge(currInd)~=grupoEtario(row))
        currInd = population(randi(numel(population),1));
        %    familySize = familyInfo(idToFamily(currInd));
    end
    % compute index in graph
    currIndGraph = numberNodesGraph+1;
    % update added nodes
    notadded(currInd) = false;
    % update graphID -> national ID
    GraphIDtoNationID(currIndGraph) = currInd;
    % update national ID -> graphID
    idToGraph(currInd) = currIndGraph;
    % update number nodes in G
    numberNodesGraph = currIndGraph;
    % update diagnosedID -> graphId
    idDiagnosedToIdGraph(idDiagnosed) = currIndGraph;
end
clear familyInfo

% choose ID for not level1 people (they have to be new nodes in the graph)
for row = notLevel1Rows
    % current number case for D person
    idDiagnosed = IDpaciente(row);
    % type of contact that infected current D person
    contactType = parentezco(row);
    % elegibles depend if they are family or not
    if(contactType == 1)
        nationalID_InfectedBy = GraphIDtoNationID(idDiagnosedToIdGraph(infectadoPor(row)));
        numFamily   = idToFamily(nationalID_InfectedBy);
        familyNodes = familyAccum(numFamily)+1:familyAccum(numFamily+1);
        elegibles   = setdiffLoc(familyNodes,nationalID_InfectedBy);
        % check node has not been added before
        if(sum((idToAge(elegibles)==grupoEtario(row)).*notadded(elegibles)')==0) % all family has been added
            % pick a random person from the corresponding county
            population = cumsum_people_per_county(canton(row))+1:cumsum_people_per_county(canton(row)+1);
            currInd = population(randi(numel(population),1));            % check node has not been added before
            while(~notadded(currInd) || idToAge(currInd)~=grupoEtario(row))
                currInd = population(randi(numel(population),1));
            end
            storeContact = 2;
        else                            % there is at least one node to add with required age group
            index       = 1;
            currInd     =  elegibles(index);
            while(~notadded(currInd) || idToAge(currInd)~=grupoEtario(row))
                index   = index + 1;
                currInd = elegibles(index);
            end
            storeContact = 1;
        end
    else
        % pick a random person from the corresponding county
        population = cumsum_people_per_county(canton(row))+1:cumsum_people_per_county(canton(row)+1);
        currInd = population(randi(numel(population),1));            % check node has not been added before
        % check node has not been added before
        while(~notadded(currInd) || idToAge(currInd)~=grupoEtario(row))
            currInd = population(randi(numel(population),1));            % check node has not been added before
        end
        % decide if is known contact or sporadic
        if(contactType == 2 || contactType == 3)
            storeContact = 2;
        else
            storeContact = 3;
        end
    end
    % create connectivity with person that infected current D
    % compute index in graph
    currIndGraph = numberNodesGraph+1;
    % update added nodes
    notadded(currInd) = false;
    % update graphID -> national ID
    GraphIDtoNationID(currIndGraph) = currInd;
    % update national ID -> graphID
    idToGraph(currInd) = currIndGraph;
    % update number nodes in G
    numberNodesGraph = currIndGraph;
    % update diagnosedID -> graphId
    idDiagnosedToIdGraph(idDiagnosed) = currIndGraph;
    % include edges in graph
    neighContacts{idDiagnosedToIdGraph(infectadoPor(row)),storeContact}(end+1) = numberNodesGraph;
    neighContacts{numberNodesGraph,storeContact}(end+1) = idDiagnosedToIdGraph(infectadoPor(row));
end
clear contactType parentezco infectadoPor canton grupoEtario level1Rows notLevel1Rows

% all D in clusters
DiagnosedClass = GraphIDtoNationID(idDiagnosedToIdGraph(IDpaciente));

% create connectivity network for diagnosed id and its contacts
for row = 1:numDiagnosticados
    currIndGraph = idDiagnosedToIdGraph(IDpaciente(row));
    currInd      = GraphIDtoNationID(currIndGraph);
    % include family for new infected people; add if not in graph
    % find family and include new nodes for new found families
    numFamily   = idToFamily(currInd);
    if(~familyAdded(numFamily)) % check if family has been added before
        % ids for family
        familyNodes = familyAccum(numFamily)+1:familyAccum(numFamily+1);
        % remove nodes already in the graph
        nodesToAdd = familyNodes(notadded(familyNodes));
        % update added nodes
        notadded(nodesToAdd) = false;
        % update graphID -> national ID
        GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
        % update national ID -> graphID
        idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
        % update total number of nodes on graph
        numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
        % list all family edges (graph number of nodes)
        allEdges = combnk(idToGraph(familyNodes),2);
        % mark family as added
        familyAdded(numFamily)= true;
        % update neighborhs
        for m = 1:size(allEdges,1)
            neighContacts{allEdges(m,1),1}(end+1) = allEdges(m,2);
            neighContacts{allEdges(m,2),1}(end+1) = allEdges(m,1);
        end
    end
    
    % include known contacts
    newConnections = max(0,degreeContacts(currInd)-numel(neighContacts{currIndGraph,2}));
    if(newConnections>0)
        % who is eligible
        population = selectPeople{idToCounty(currInd)};
        elegiblesW = population(randi(numel(population),1,3*newConnections)); %nuevo
        elegiblesW = setdiffLoc(elegiblesW, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
        newCoworkers = elegiblesW(randperm(numel(elegiblesW),newConnections));
        % find preexisting nodes on the graph
        nodesToAdd = newCoworkers(notadded(newCoworkers));
        % update added
        notadded(nodesToAdd) = false;
        % keep track of order of nodes
        GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
        idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
        numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
        % add edges
        allEdges = idToGraph(newCoworkers);
        % update neighborhs
        neighContacts{currIndGraph,2}(end+1:end+numel(allEdges)) = allEdges;
        for m = 1:numel(allEdges)
            neighContacts{allEdges(m),2}(end+1) = currIndGraph;
        end
    end
    
    % include sporadic contacts
    newConnections = max(0,degreeSporadic(currInd)-numel(neighContacts{currIndGraph,3}));
    if(newConnections>0)
        % who is eligible
        population = selectPeople{idToCounty(currInd)};
        elegiblesF = population(randi(numel(population),1,3*newConnections)); %nuevo
        elegiblesF = setdiffLoc(elegiblesF, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
        newFriends   = elegiblesF(randperm(numel(elegiblesF),newConnections));
        % find preexisting nodes on the graph
        nodesToAdd = newFriends(notadded(newFriends));
        % update added
        notadded(nodesToAdd) = false;
        % keep track of order of nodes
        GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
        idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
        numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
        % add edges
        allEdges = idToGraph(newFriends);
        % update neighborhs
        neighContacts{currIndGraph,3}(end+1:end+numel(allEdges)) = allEdges;
        for m = 1:numel(allEdges)
            neighContacts{allEdges(m),3}(end+1) = currIndGraph;
        end
    end
end

for j = 1:numberNodesGraph % remove repetitions from first for
    neighContacts{j,1} = uniqueLoc(neighContacts{j,1});
    neighContacts{j,2} = uniqueLoc(neighContacts{j,2});
    neighContacts{j,3} = uniqueLoc(neighContacts{j,3});
end

nexos = [];
% include exposed date (based on diagnosed date) and include U people
for time = 1:(numDias-testTime)
    
    % current day
    currentDay = t1 + time - 1;
    % find entries with current Day
    rows = ismember(fechaDiagnost,currentDay);
    % D people with current date
    indexGraph = idDiagnosedToIdGraph(IDpaciente(rows));
    indexD     = GraphIDtoNationID(indexGraph);
    % number of new U
    Dtoday = numel(indexD);
    % 75D-25U
    Utoday = floor(Dtoday*(1-RatioDiagnosedOverInfected)/RatioDiagnosedOverInfected);
    % randomly choose U from network
    if(Utoday>0)
        allNeigh = [];
        for k = indexGraph'
            allNeigh = [allNeigh, neighContacts{k,1}, neighContacts{k,2}, neighContacts{k,3}];
        end
        % people not in D
        allNeigh = setdiffLoc(allNeigh,idToGraph(DiagnosedClass));
        indexU = GraphIDtoNationID(allNeigh(randsample(numel(allNeigh),Utoday)));
        
        % include networks for U
        for k = indexU
            currInd      = k;%GraphIDtoNationID(currIndGraph);
            currIndGraph = idToGraph(currInd);%idDiagnosedToIdGraph(IDpaciente(row));
            % include family for new infected people; add if not in graph
            % find family and include new nodes for new found families
            numFamily   = idToFamily(currInd);
            if(~familyAdded(numFamily)) % check if family has been added before
                % ids for family
                familyNodes = familyAccum(numFamily)+1:familyAccum(numFamily+1);
                % remove nodes already in the graph
                nodesToAdd = familyNodes(notadded(familyNodes));
                % update added nodes
                notadded(nodesToAdd) = false;
                % update graphID -> national ID
                GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
                % update national ID -> graphID
                idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
                % update total number of nodes on graph
                numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
                % list all family edges (graph number of nodes)
                allEdges = combnk(idToGraph(familyNodes),2);
                % mark family as added
                familyAdded(numFamily)= true;
                % update neighborhs
                for m = 1:size(allEdges,1)
                    neighContacts{allEdges(m,1),1}(end+1) = allEdges(m,2);
                    neighContacts{allEdges(m,2),1}(end+1) = allEdges(m,1);
                end
            end
            
            % include known contacts
            newConnections = max(0,degreeContacts(currInd)-numel(neighContacts{currIndGraph,2}));
            if(newConnections>0)
                % who is eligible
                population = selectPeople{idToCounty(currInd)};
                elegiblesW = population(randi(numel(population),1,3*newConnections)); %nuevo
                elegiblesW = setdiffLoc(elegiblesW, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
                newCoworkers = elegiblesW(randperm(numel(elegiblesW),newConnections));
                % find preexisting nodes on the graph
                nodesToAdd = newCoworkers(notadded(newCoworkers));
                % update added
                notadded(nodesToAdd) = false;
                % keep track of order of nodes
                GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
                idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
                numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
                % add edges
                allEdges = idToGraph(newCoworkers);
                % update neighborhs
                neighContacts{currIndGraph,2}(end+1:end+numel(allEdges)) = allEdges;
                for m = 1:numel(allEdges)
                    neighContacts{allEdges(m),2}(end+1) = currIndGraph;
                end
            end
            
            % include sporadic contacts
            newConnections = max(0,degreeSporadic(currInd)-numel(neighContacts{currIndGraph,3}));
            if(newConnections>0)
                % who is eligible
                population = selectPeople{idToCounty(currInd)};
                elegiblesF = population(randi(numel(population),1,3*newConnections)); %nuevo
                elegiblesF = setdiffLoc(elegiblesF, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
                newFriends   = elegiblesF(randperm(numel(elegiblesF),newConnections));
                % find preexisting nodes on the graph
                nodesToAdd = newFriends(notadded(newFriends));
                % update added
                notadded(nodesToAdd) = false;
                % keep track of order of nodes
                GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
                idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
                numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
                % add edges
                allEdges = idToGraph(newFriends);
                % update neighborhs
                neighContacts{currIndGraph,3}(end+1:end+numel(allEdges)) = allEdges;
                for m = 1:numel(allEdges)
                    neighContacts{allEdges(m),3}(end+1) = currIndGraph;
                end
            end
        end
        timeCompartmentE(indexU) = currentDay - IncubationPeriod;
        nexos = [nexos indexU];
    end
    % store date for E
    timeCompartmentE(indexD) = currentDay - IncubationPeriod;
    nexos = [nexos indexD];
end
nexos = unique(nexos);

clear IDpaciente fechaDiagnost

firstTimeE2 = 1; % en cada grupo etario
firstTimeE3 = 1;
firstTimeE1 = 1;

% set dates for cases in the cluster file
for time = 1:(numDias-testTime)
    
    
    %%Cambiar parametros
    if time==216    %Oct1
        
        PercDiagnosedToHospital_G1 = .0158;  %  2.2 % D se hospitalizan - G1
        PercDiagnosedToHospital_G2 = .0344;  %  4.7 % D se hospitalizan - G2
        PercDiagnosedToHospital_G3 = .3444;  % 37.1 % D se hospitalizan - G3
        
        PercDiagnosedToHospital_G1_V = .0;         %JG0622
        PercDiagnosedToHospital_G2_V = .0344*lesshosp; %JG0622
        PercDiagnosedToHospital_G3_V = .344*lesshosp;  %JG0622
        
        PercHtoUCI_G1              = .132;     % 14 % H a UCI - G1
        PercHtoUCI_G2              = .35;      % 27 % H a UCI - G2
        PercHtoUCI_G3              = .34;      % 30 % H a UCI - G3
        
        PercHtoR_G2                = .953;    %  95 % H a R - G2 (mortalidad 4%)
        PercHtoR_G3                = .757;    %  90 % H a R - G3 (mortalidad 28%)
        
        PercUCIrecovers_G2         = .764;    %  88 % UCIs to R - G1 (mortalidad 23%)
        PercUCIrecovers_G3         = .535;    %  76 % UCIs to R - G1 (mortalidad 44%)
      
        DaysHtoUCI                 = 3;      % tiempo H a UCI
    end
    
    %%Cambiar parametros
    if time>=370    % Marzo 1 (primera semana epidemiologica)
        PercDiagnosedToHospital_G1 = .0205;  %  2.2 % D se hospitalizan - G1
        PercDiagnosedToHospital_G2 = .0668;    %  4.7 % D se hospitalizan - G2
        PercDiagnosedToHospital_G3 = .356;  % 37.1 % D se hospitalizan - G3
        
        PercDiagnosedToHospital_G1_V = .0;         %JG0622
        PercDiagnosedToHospital_G2_V = .0668*lesshosp; %JG0622
        PercDiagnosedToHospital_G3_V =  0.356*lesshosp;  %JG0622
        
        PercHtoUCI_G1              = .135;      % 14 % H a UCI - G1
        PercHtoUCI_G2              = .358;      % 27 % H a UCI - G2
        PercHtoUCI_G3              = .344;      % 30 % H a UCI - G3
        
        PercHtoR_G2                = .9535;      %  95 % H a R - G2 (mortalidad 4%)
        PercHtoR_G3                = .7051;      %  90 % H a R - G3 (mortalidad 28%)
        
        PercUCIrecovers_G2         = .788;       %  88 % UCIs to R - G1 (mortalidad 23%)
        PercUCIrecovers_G3         = .506;       %  76 % UCIs to R - G1 (mortalidad 44%)
    end
       
    if time>= 431 %Mayo 1  %450    % Mayo 120       
         
        DaysUCI_G1                 = 5;      %4 tiempo en UCI - G1
        DaysUCI_G2                 = 10; %8;      % tiempo en UCI - G2
        DaysUCI_G3                 = 9; %7;      % tiempo en UCI - G3
        
        PercHtoR_G2                = .96;      %  95 % H a R - G2 (mortalidad 4%)
        PercHtoR_G3                = .71;      %  90 % H a R - G3 (mortalidad 28%)
        
        PercUCIrecovers_G2         = .77;       %  88 % UCIs to R - G1 (mortalidad 23%)
        PercUCIrecovers_G3         = .50;       %  76 % UCIs to R - G1 (mortalidad 44%)
    end
       
    if(time>=422)   %Abril 22 %Cambia el tiempo para pasar a RR
       ImmunityTimeR = 1; 
    end
    
    if(time>=455) %Mayo25 Se cambia el esquema para la segunda dosis
        TimeSV =  84;   %84 días menos los dias que dura sin proteccion
    end
    
    %%%-----------------------------------------------------------------YG
    if(Lim1V2<=accumV2(time) && accumV2(time)<=Lim2V2)
        lesshosp = (1-0.85);
    elseif(accumV2(time)>=Lim2V2)
        lesshosp = (1-0.90);   
    end
    
    if(time>=502)
        num      = randsample([35,40,45,50], 1);
        pUseDist = (num+20*rand(81,1))/100;
    end

    %%%Escenario 1--------------------------------------------------------

    if(accumV2(time)>=Lim2V2)
        %%%Distanciamiento social
        num      = randsample([20,25,30,35], 1);
        pUseDist = (num+20*rand(81,1))/100;
        
        %%% Uso de protección personal
        pUseMask = randsample([0.50,0.55,0.60,0.65,0.70], 1);
    end
    
    
    %%%----------------------------------------------------------------JGC
    if(time<=412) % ultima fecha en base de vacunacion
        DosesE2 = sum((infoVac(:,1)==time).*(infoVac(:,4)==1));
        DosesE3 = sum((infoVac(:,1)==time).*(infoVac(:,5)==1));
    end % después del día 412 los números quedan como el último
    %%%----------------------------------------------------------------JGC       
   
    if(413<= time && time<=419) %abril13-aril19
         DosesE2 =  2064;
         DosesE3 =  11693;
    elseif(420<=time && time<427) %Abril 20 - Abril27
         DosesE2 =  1888;
         DosesE3 =  10693;
    elseif(427<=time && time<= 434) %Abril 28 - Mayo4 en Adelante
         DosesE2 =  1424;
         DosesE3 =  8064;
    elseif(435<=time && time<= 441) %Mayo 5 - Mayo11 en Adelante
         DosesE2 =  1118;
         DosesE3 =  6339;
    elseif(442<=time && time <=448) %Mayo12-Mayo 18
         DosesE2 =  1383;
         DosesE3 =  7842;
    elseif(449<=time && time<=455)  %Mayo19-Mayo 25
         DosesE2 =  3120;
         DosesE3 =  17684; 
    elseif(456<=time && time<=463)  %Mayo 26 -Junio 2 
         DosesE2 =  3103;
         DosesE3 =  17584; 
    elseif(464<=time && time<=469)  %Junio 3 - Junio 8
         DosesE2 =  4440;
         DosesE3 =  25160; 
    elseif(470<=time && time<=476)  %Junio 9 - Junio 15
         DosesE2 =  4076;
         DosesE3 =  23098; 
    elseif(477<=time && time<=483)  %Junio 16 - Junio 22
         DosesE2 =  2704;
         DosesE3 =  15322; 
    elseif(484<=time && time<=490)  %Junio 23 - Junio 29
         DosesE2 =  1998;
         DosesE3 =  11323;
    elseif(491<=time && time<=497)  %Junio 30 - Julio 6
         DosesE2 =  1620;
         DosesE3 =  9186; 
    elseif(498<= time && time<=503)  %Julio7 - Julio 13
         DosesE2 =  1694;
         DosesE3 =  9603; 
   elseif(504<= time && time<=510)  %Julio14 - Julio20
         DosesE2 =  4253;
         DosesE3 =  24103; 
   elseif(511<= time && time<=517)  %Julio20 - July 27
         DosesE2 =  7928;
         DosesE3 =  44925;
  elseif(518<= time && time<=522)  %Julio28 -Agosto2
         DosesE2 =  4730;
         DosesE3 =  26806;
   elseif(time>=523)  %Agosto2
         DosesE2 =  1950;
         DosesE3 =  11050;   
   end
    
          
    % S->E
    currentDay = t1 + time-1-IncubationPeriod;
    index = timeCompartmentE==currentDay;
    if(sum(index)>0)
        SS(index) = false;
        SE(index) = true;
    end
    
    % E -> D, E -> U
    index = currentDay-timeCompartmentE == IncubationPeriod;
    if(sum(index)>0)
        index = find(index);
        ages  = idToAge(index);
        vacc = double(Vac(index))'; %JG0622
        
        %------JG0622
        i1 = (ages==1).*(index);
        i1v= i1.*vacc;
        i1v = i1v(i1v>0);
        i1 = i1(i1>0);           % D and U
        i1 = setdiff(i1,i1v);
        
        i2 = (ages==2).*(index);
        i2v= i2.*vacc;
        i2v = i2v(i2v>0);
        i2 = i2(i2>0);           % D and U
        i2 = setdiff(i2,i2v);

        i3 = (ages==3).*(index);
        i3v= i3.*vacc;
        i3v = i3v(i3v>0);
        i3 = i3(i3>0);           % D and U
        i3 = setdiff(i3,i3v); 
        %------JG0622
        
        indexD1 = intersect(DiagnosedClass,i1);
        indexD2 = intersect(DiagnosedClass,i2);
        indexD3 = intersect(DiagnosedClass,i3);
        indexU1 = setdiffLoc(i1,indexD1);
        indexU2 = setdiffLoc(i2,indexD2);
        indexU3 = setdiffLoc(i3,indexD3);
        
        indexD1V = i1v; %JG0622
        indexD2V = i2v; %JG0622
        indexD3V = i3v; %JG0622

        requireHfromD1 = indexD1(logical(randsample(2,numel(indexD1),true,[1-PercDiagnosedToHospital_G1, PercDiagnosedToHospital_G1])-1)); % 1 if D will require H at day 4
        requireHfromD2 = indexD2(logical(randsample(2,numel(indexD2),true,[1-PercDiagnosedToHospital_G2, PercDiagnosedToHospital_G2])-1)); % 1 if D will require H at day 4
        requireHfromD3 = indexD3(logical(randsample(2,numel(indexD3),true,[1-PercDiagnosedToHospital_G3, PercDiagnosedToHospital_G3])-1)); % 1 if D will require H at day 4

        requireHfromD1V = indexD1V(logical(randsample(2,numel(indexD1V),true,[1-PercDiagnosedToHospital_G1_V, PercDiagnosedToHospital_G1_V])-1)); %JG0622
        requireHfromD2V = indexD2V(logical(randsample(2,numel(indexD2V),true,[1-PercDiagnosedToHospital_G2_V, PercDiagnosedToHospital_G2_V])-1)); %JG0622
        requireHfromD3V = indexD3V(logical(randsample(2,numel(indexD3V),true,[1-PercDiagnosedToHospital_G3_V, PercDiagnosedToHospital_G3_V])-1)); %JG0622

        requireHfromU1 = indexU1(logical(randsample(2,numel(indexU1),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        requireHfromU2 = indexU2(logical(randsample(2,numel(indexU2),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        requireHfromU3 = indexU3(logical(randsample(2,numel(indexU3),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        
        willDiefromD1  = indexD1(logical(randsample(2,numel(indexD1),true,[1-PercDeathsDU, PercDeathsDU])-1)); % 1 if D will require H at day 4
        willDiefromD2  = indexD2(logical(randsample(2,numel(indexD2),true,[1-PercDeathsDU, PercDeathsDU])-1)); % 1 if D will require H at day 4
        willDiefromD3  = indexD3(logical(randsample(2,numel(indexD3),true,[1-PercDeathsDU, PercDeathsDU])-1)); % 1 if D will require H at day 4

        willDiefromU1  = indexU1(logical(randsample(2,numel(indexU1),true,[1-PercDeathsDU, PercDeathsDU])-1)); % 1 if D will require H at day 4
        willDiefromU2  = indexU2(logical(randsample(2,numel(indexU2),true,[1-PercDeathsDU, PercDeathsDU])-1)); % 1 if D will require H at day 4
        willDiefromU3  = indexU3(logical(randsample(2,numel(indexU3),true,[1-PercDeathsDU, PercDeathsDU])-1)); % 1 if D will require H at day 4

        
        willDiefromD1  = setdiffLoc(willDiefromD1,requireHfromD1);
        willDiefromD2  = setdiffLoc(willDiefromD2,requireHfromD2);
        willDiefromD3  = setdiffLoc(willDiefromD3,requireHfromD3);
        
        willDiefromU1  = setdiffLoc(willDiefromU1,requireHfromU1);
        willDiefromU2  = setdiffLoc(willDiefromU2,requireHfromU2);
        willDiefromU3  = setdiffLoc(willDiefromU3,requireHfromU3);
        
        
        noRequireHfromD1 = setdiffLoc(indexD1,[requireHfromD1 willDiefromD1]);
        noRequireHfromD2 = setdiffLoc(indexD2,[requireHfromD2 willDiefromD2]);
        noRequireHfromD3 = setdiffLoc(indexD3,[requireHfromD3 willDiefromD3]);
        
        noRequireHfromD1V = setdiffLoc(indexD1V, requireHfromD1V); %JG0622
        noRequireHfromD2V = setdiffLoc(indexD2V, requireHfromD2V); %JG0622
        noRequireHfromD3V = setdiffLoc(indexD3V, requireHfromD3V); %JG0622

        
        noRequireHfromU1 = setdiffLoc(indexU1,[requireHfromU1 willDiefromU1]);
        noRequireHfromU2 = setdiffLoc(indexU2,[requireHfromU2 willDiefromU2]);
        noRequireHfromU3 = setdiffLoc(indexU3,[requireHfromU3 willDiefromU3]);
        
        noRequireHfromD = [noRequireHfromD1 noRequireHfromD2 noRequireHfromD3 noRequireHfromD1V noRequireHfromD2V noRequireHfromD3V]; %JG0622
        %noRequireHfromD = [noRequireHfromD1 noRequireHfromD2 noRequireHfromD3];
        noRequireHfromU = [noRequireHfromU1 noRequireHfromU2 noRequireHfromU3];
        requireHfromD   = [requireHfromD1 requireHfromD2 requireHfromD3 requireHfromD1V requireHfromD2V requireHfromD3V]; %JG0622
        %requireHfromD   = [requireHfromD1 requireHfromD2 requireHfromD3];
        requireHfromU   = [requireHfromU1 requireHfromU2 requireHfromU3];
        
        willDiefromD    = [willDiefromD1 willDiefromD2 willDiefromD3];
        willDiefromU    = [willDiefromU1 willDiefromU2 willDiefromU3];
        
        % save changes compartiment
        SE(index)           = false;
        SD(noRequireHfromD) = true;
        SU(noRequireHfromU) = true;
        SDH(requireHfromD)  = true;
        SUH(requireHfromU)  = true;
        SDD(willDiefromD)   = true;
        SUD(willDiefromU)   = true;
        % save time
        timeCompartmentD(noRequireHfromD) = currentDay;
        timeCompartmentU(noRequireHfromU) = currentDay;
        timeCompartmentDH(requireHfromD)  = currentDay;
        timeCompartmentUH(requireHfromU)  = currentDay;
        timeCompartmentDD(willDiefromD)   = currentDay;
        timeCompartmentUD(willDiefromU)   = currentDay;
        indexD = [indexD1 indexD2 indexD3];
    else % indexD is required to compute accumD
        indexD = [];
    end
    
    newH = []; % JG0816
    % check UH -> H
    index = currentDay-timeCompartmentUH == DaysUndiagnosedToHospital;
    if(sum(index)>0)
        SUH(index) = false;
        SH(index)  = true;
        timeCompartmentH(index) = currentDay;
        newH = [newH find(index)]; % JG0816
    end
    
    % check DH -> H
    index = currentDay-timeCompartmentDH == DaysDiagnosedToHospital;
    if(sum(index)>0)
        SDH(index)  = false;
        SH(index)   = true;
        timeCompartmentH(index) = currentDay;
        newH = [newH find(index)]; % JG0816
    end
    
    index = currentDay-timeCompartmentUD == 10;
    if(sum(index)>0)
        SUD(index)   = false;
        SDead(index) = true;
    end
    
    index = currentDay-timeCompartmentDD == 10;
    if(sum(index)>0)
        SDD(index)   = false;
        SDead(index) = true;
    end
       
    % check for recoveries D -> R
    index     = currentDay-timeCompartmentD == DaysToRecoverDiagnosed;
    SR(index) = true;
    SD(index) = false;
    timeCompartmentR(index) = currentDay;
    
    % check for recoveries U -> R
    index = currentDay-timeCompartmentU == DaysToRecoverUndiagnosed;
    SR(index) = true;
    SU(index) = false;
    timeCompartmentR(index) = currentDay;
    
    % check H -> UCI
    index = currentDay-timeCompartmentH == DaysHtoUCI;
    if(sum(index)>0)
        index = find(index);
        ages  = idToAge(index);
        i1    = (ages==1).*(index);
        i1    = i1(i1>0);           % D and U
        i2    = (ages==2).*(index);
        i2    = i2(i2>0);           % D and U
        i3    = (ages==3).*(index);
        i3    = i3(i3>0);           % D and U
        
        HtoUCI1 = i1(logical(randsample(2,numel(i1),true,[1-PercHtoUCI_G1, PercHtoUCI_G1])-1)); % 1 if goes to UCI
        HtoUCI2 = i2(logical(randsample(2,numel(i2),true,[1-PercHtoUCI_G2, PercHtoUCI_G2])-1)); % 1 if goes to UCI
        HtoUCI3 = i3(logical(randsample(2,numel(i3),true,[1-PercHtoUCI_G3, PercHtoUCI_G3])-1)); % 1 if goes to UCI
        HtoUCI  = [HtoUCI1 HtoUCI2 HtoUCI3];
        SH(HtoUCI)   = false;
        SUCI(HtoUCI) = true;
        % save time
        timeCompartmentUCI(HtoUCI) = currentDay;
        timeCompartmentH(HtoUCI)   = Inf;
    else
        HtoUCI1 = []; % JG0816
        HtoUCI2 = []; % JG0816
        HtoUCI3 = []; % JG0816
    end
    
    % check H -> R or dead
    index = currentDay-timeCompartmentH == DaysHospitalized_G1; % people with 14 days in H goes to R
    if(sum(index)>0)                % find people group age 1
        index  = find(index);       % nationalID people with 14 days in H
        ages   = idToAge(index);    % age of all people with 14 days in H
        index  = (ages==1).*(index);
        index  = index(index>0);          % people on group 1 with 14 days in H
        HtoR   = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G1, PercHtoR_G1])-1)); % 1 if recovers
        Hdies  = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        timeCompartmentH(index) = Inf;
        timeCompartmentR(HtoR) = currentDay;
    end
    index = currentDay-timeCompartmentH == DaysHospitalized_G2; % people with 14 days in H goes to R
    if(sum(index)>0)              % find people group age 1
        index  = find(index);     % nationalID people with 14 days in H
        ages   = idToAge(index);  % age of all people with 14 days in H
        index  = (ages==2).*(index);
        index  = index(index>0);          % people on group 1 with 14 days in H
        HtoR   = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G2, PercHtoR_G2])-1)); % 1 if recovers
        Hdies  = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        timeCompartmentH(index) = Inf;
        timeCompartmentR(HtoR) = currentDay;
    end
    index = currentDay-timeCompartmentH == DaysHospitalized_G3; % people with 14 days in H goes to R
    if(sum(index)>0)              % find people group age 1
        index  = find(index);     % nationalID people with 14 days in H
        ages   = idToAge(index);  % age of all people with 14 days in H
        index  = (ages==3).*(index);
        index  = index(index>0);          % people on group 1 with 14 days in H
        HtoR   = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G3, PercHtoR_G3])-1)); % 1 if recovers
        Hdies  = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        timeCompartmentH(index) = Inf;
        timeCompartmentR(HtoR)  = currentDay;
    end
    
    % check UCI -> R or dead
    index = currentDay-timeCompartmentUCI == DaysUCI_G1;
    if(sum(index)>0)
        index    = find(index);
        ages     = idToAge(index);
        index    = (ages==1).*(index);
        index    = index(index>0);          % people on group 1 with 14 days in H
        UCItoR   = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G1, PercUCIrecovers_G1])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        timeCompartmentR(UCItoR)  = currentDay;
    end
    index = currentDay-timeCompartmentUCI >= DaysUCI_G2;
    if(sum(index)>0)
        index   = find(index);
        ages    = idToAge(index);
        index   = (ages==2).*(index);
        index   = index(index>0);          % people on group 1 with 14 days in H
        UCItoR  = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G2, PercUCIrecovers_G2])-1)); % 1 if recovers
        UCIdies = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        timeCompartmentR(UCItoR)  = currentDay;
    end
    index = currentDay-timeCompartmentUCI >= DaysUCI_G3;
    if(sum(index)>0)
        index  = find(index);
        ages   = idToAge(index);
        index  = (ages==3).*(index);
        index  = index(index>0);          % people on group 1 with 14 days in H
        UCItoR = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G3, PercUCIrecovers_G3])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        timeCompartmentR(UCItoR)  = currentDay;
    end
    
    %%%-------------------nuevas transiciones------------------------------
    %S->V1 RR->V1
    if(time>=vaccineTime)
        Rem     = RR.*~Vac; %JG0622
        index1  = find(SS);         % encontramos personas susceptibles
        %index2  = find(RR);%JG0622
        index2  = find(Rem); %JG0622
        index   = [index1' index2'];
        %numel(index)
        index = setdiff(index,nexos);      % removemos gente de la base de nexos
        index = setdiff(index,noSeVacunan); % removemos gente que no se vacuna %JG0809
        
        ages  = idToAge(index);
        i1    = (ages==1).*(index);
        i1    = i1(i1>0);
        i2    = (ages==2).*(index);
        i2    = i2(i2>0);
        i3    = (ages==3).*(index);
        i3    = i3(i3>0);
        
        if(length(i3)>=DosesE3)
            StoVE3 = randsample(i3, DosesE3); % adulto mayor vacunado por dia
        else
            DosesE2 = DosesE2+DosesE3;
            StoVE3  = [];
            if(firstTimeE3 == 1)
                StoVE3  = i3;
                firstTimeE3=0; 
            end
        end
        
        if(length(i2)>=DosesE2)
            StoVE2 = randsample(i2, DosesE2); % adulto mayor vacunado por dia
        else
            DosesE1= DosesE2;
            StoVE3 = [];
            StoVE2 = [];
            if(firstTimeE2 == 1)
                StoVE2  = i2;
                firstTimeE2=0; 
            end
             
            faltan = length(i1)-(1486794-TotalVacE1);
            if(DosesE1<=faltan)
                StoVE1 = randsample(i1, DosesE1); % adulto mayor vacunado por dia
            elseif(firstTimeE1 == 1)
                StoVE1     =  randsample(i1, faltan);
                firstTimeE1=0; 
            else
                 StoVE3 = [];
                 StoVE2 = [];
                 StoVE1 = [];
            end
        end
        
        StoV1  = [StoVE1 StoVE2 StoVE3];    %Total Vacunados
        Vac(StoV1) = true; %JG0622
        SV1(StoV1) = true;           %Vacunados entran en un estado V pero siguen siendo susceptibles
        SS(StoV1)  = false;          %Removemos vacunados de S y RR
        RR(StoV1)  = false;
        timeCompartmentV1(StoV1) = currentDay;  %save time
    else
        StoV1 = [];
        StoVE1 = [];
        StoVE2 = [];
        StoVE3 = [];
    end
    
    %V1->V2  %Removemos los vacunados del compartimento de los susceptibles
    index = currentDay-timeCompartmentV1 == TimeSV;
    if(sum(index)>0)
        SV1(index) = false;
        SV2(index) = true;                %Personas vacunadas
        timeCompartmentV2(index) = currentDay;
        timeCompartmentV1(index) = Inf;
        index = find(index);
        ages  = idToAge(index);
        i1    = (ages==1).*(index);
        StoV2E1    = i1(i1>0);
        i2    = (ages==2).*(index);
        StoV2E2    = i2(i2>0);
        i3    = (ages==3).*(index);
        StoV2E3    = i3(i3>0);
        StoV2 = [StoV2E1 StoV2E2 StoV2E3];
    else
        StoV2 = [];
        StoV2E1 = [];
        StoV2E2 = [];
        StoV2E3 = [];
    end
    
    %R->RR (Despues de 90 días las personas infectadas pueden ser elegibles para ser vacunadas)
    
    index = currentDay-timeCompartmentR == ImmunityTimeR;
    if(sum(index)>0)
        SR(index)=false;
        RR(index)=true;
        timeCompartmentR(index)=Inf;
    end
    
    %%%--------------------------------------------------------------------
    
    
    iu    = (SU==1|SUH==1|SUD==1)';
    id    = (SD==1|SDH==1|SDD==1)';
    ih    = (SH==1)';
    iuci  = (SUCI==1)';
    idead = (SDead==1)';
    iV1   = (SV1==1)';   %%%vaccine
    iV2   = (SV2==1)';   %%%vaccine
    % update
    totalH(time+1)    = sum(SH);
    totalUCI(time+1)  = sum(SUCI);
    totalV1(time+1)   = sum(SV1);   %%%%%%%%%%-----Guardar los vacunados con una dosis --------
    totalV2(time+1)   = sum(SV2);   %%%%%%%%%%-----Guardar los vacunados con dos dosis --------
    totalD(time+1)    = sum(SD)+sum(SDH)+sum(SDD);
    totalU(time+1)    = sum(SU)+sum(SUH)+sum(SUD);
    totalDead(time+1) = sum(SDead);
    totalS(time+1) = sum(SS);
    totalE(time+1) = sum(SE);
    totalR(time+1) = sum(SR);
    totalRR(time+1) = sum(RR);
    accumD(time+1)    = accumD(time) + numel(indexD);
    accumV1(time+1)   = accumV1(time) + numel(StoV1); % JG20712
    accumV1E1(time+1) = accumV1E1(time) + numel(StoVE1); % JG20712
    accumV1E2(time+1) = accumV1E2(time) + numel(StoVE2); % JG20712
    accumV1E3(time+1) = accumV1E3(time) + numel(StoVE3); % JG20712
    accumV2(time+1)   = accumV2(time) + numel(StoV2); % JG20712
    accumV2E1(time+1) = accumV2E1(time)+ numel(StoV2E1);
    accumV2E2(time+1) = accumV2E2(time)+ numel(StoV2E2);
    accumV2E3(time+1) = accumV2E3(time)+ numel(StoV2E3);
    accumD1(time+1)   = accumD1(time) + sum(idToAge(indexD)==1);
    accumD2(time+1)   = accumD2(time) + sum(idToAge(indexD)==2);
    accumD3(time+1)   = accumD3(time) + sum(idToAge(indexD)==3);
    nuevosUCI1(time+1)= numel(HtoUCI1); % JG0816
    nuevosUCI2(time+1)= numel(HtoUCI2); % JG0816
    nuevosUCI3(time+1)= numel(HtoUCI3); % JG0816
    % salvar segun edad
    i1 = (idToAge==1);
    totalU1(time+1)    = sum(iu & i1);
    totalD1(time+1)    = sum(id & i1);
    totalH1(time+1)    = sum(ih & i1);
    totalUCI1(time+1)  = sum(iuci & i1);
    totalDead1(time+1) = sum(idead & i1);
    totalV1E1(time+1)  = sum(iV1 & i1);  %%vaccine
    totalV2E1(time+1)  = sum(iV2 & i1);  %%vaccine 
       
    i1 = (idToAge==2);
    totalU2(time+1)    = sum(iu & i1);
    totalD2(time+1)    = sum(id & i1);
    totalH2(time+1)    = sum(ih & i1);
    totalUCI2(time+1)  = sum(iuci & i1);
    totalDead2(time+1) = sum(idead & i1);
    totalV1E2(time+1)  = sum(iV1 & i1);  %%vaccine
    totalV2E2(time+1)  = sum(iV2 & i1);  %%vaccine 
    
    i1 = (idToAge==3);
    totalU3(time+1)    = sum(iu & i1);
    totalD3(time+1)    = sum(id & i1);
    totalH3(time+1)    = sum(ih & i1);
    totalUCI3(time+1)  = sum(iuci & i1);
    totalDead3(time+1) = sum(idead & i1);
    totalV1E3(time+1)  = sum(iV1 & i1);  %%vaccine
    totalV2E3(time+1)  = sum(iV2 & i1);  %%vaccine 
     
    age = idToAge(newH);            % JG0816
    nuevosH1(time+1) = sum(age==1); % JG0816
    nuevosH2(time+1) = sum(age==2); % JG0816
    nuevosH3(time+1) = sum(age==3); % JG0816
    
    if(countyInfo)
        dataMap(:,time+1) = hist(idToCounty(logical(SD+SDH)),1:81); %#ok<*HIST,*UNRCH> % D
        del = hist(idToCounty(indexD),1:81)';
        dataMapAcum(:,time+1) = dataMapAcum(:,time)+del;
        % hospis y UCIs y muertes epor canton
        dataMapUCI(:,time+1) = hist(idToCounty(logical(SUCI)),1:81);
        dataMapH(:,time+1)   = hist(idToCounty(logical(SH)),1:81);
        dataMapMuertes(:,time+1) = hist(idToCounty(logical(SDead)),1:81);
        dataMapU(:,time+1)   = hist(idToCounty(logical(SU+SUH)),1:81);
    end
end
clear DiagnosedClass

%%%%%%%%%%%% 
%%% CAMBIO
% proyecciones
% pUseDist = (40+20*rand(81,1))/100;
%%% CAMBIO
for time = (numDias-testTime+1):T % numDias = 137
    
     %%Cambiar parametros
    if time>=370    %Marzo 1 (primera semana epidemiologica)
        PercDiagnosedToHospital_G1 = .0205;  %  2.2 % D se hospitalizan - G1
        PercDiagnosedToHospital_G2 = .0668;    %  4.7 % D se hospitalizan - G2
        PercDiagnosedToHospital_G3 = .356;  % 37.1 % D se hospitalizan - G3
        
        PercDiagnosedToHospital_G1_V = .0;         %JG0622
        PercDiagnosedToHospital_G2_V = .0668*lesshosp; %JG0622
        PercDiagnosedToHospital_G3_V =  0.356*lesshosp;  %JG0622
    
        PercHtoUCI_G1              = .135;      % 14 % H a UCI - G1
        PercHtoUCI_G2              = .358;      % 27 % H a UCI - G2
        PercHtoUCI_G3              = .344;      % 30 % H a UCI - G3
       
        PercHtoR_G2                = .9535;      %  95 % H a R - G2 (mortalidad 4%)
        PercHtoR_G3                = .7051;      %  90 % H a R - G3 (mortalidad 28%)
        
        PercUCIrecovers_G2         = .788;       %  88 % UCIs to R - G1 (mortalidad 23%)
        PercUCIrecovers_G3         = .506;       %  76 % UCIs to R - G1 (mortalidad 44%)
    end
    

    %%Cambiar parametros
    if time>= 431 %Mayo 1    %450    % Mayo 120       
        DaysUCI_G1                 = 5;      %4 tiempo en UCI - G1
        DaysUCI_G2                 = 10; %8;      % tiempo en UCI - G2
        DaysUCI_G3                 = 9; %7;      % tiempo en UCI - G3
        
        PercHtoR_G2                = .96;      %  95 % H a R - G2 (mortalidad 4%)
        PercHtoR_G3                = .71;      %  90 % H a R - G3 (mortalidad 28%)
        
        PercUCIrecovers_G2         = .77;       %  88 % UCIs to R - G1 (mortalidad 23%)
        PercUCIrecovers_G3         = .50;       %  76 % UCIs to R - G1 (mortalidad 44%)
    end
       
    if(time>=422)   %Abril 22 %Cambia el tiempo para pasar a RR
       ImmunityTimeR = 1; 
    end
    
    if(time>=455) %Mayo25 Se cambia el esquema para la segunda dosis
        TimeSV =  84;   %84 días menos los dias que dura sin proteccion
    end
    
    disp(accumV2(time))
    %%%-----------------------------------------------------------------YG
    if(Lim1V2<=accumV2(time) && accumV2(time)<=Lim2V2)
        lesshosp = (1-0.85);
    elseif(accumV2(time)>=Lim2V2)
        lesshosp = (1-0.90);   
    end
    
    if(time>=502)
        num      = randsample([35,40,45,50], 1);
        pUseDist = (num+20*rand(81,1))/100;
    end
    
    %%%Escenario 1--------------------------------------------------------
    disp(accumV2(time))
    if(accumV2(time)>=Lim2V2)
        %%%Distanciamiento social
        num      = randsample([20,25,30,35], 1);
        pUseDist = (num+20*rand(81,1))/100;
        
        %%% Uso de protección personal
        pUseMask = randsample([0.50,0.55,0.60,0.65,0.70], 1);
    end
    
    %%%----------------------------------------------------------------JGC
    if(time<=412) % ultima fecha en base de vacunacion
        DosesE2 = sum((infoVac(:,1)==time).*(infoVac(:,4)==1));
        DosesE3 = sum((infoVac(:,1)==time).*(infoVac(:,5)==1));
    end % después del día 412 los números quedan como el último
    %%%----------------------------------------------------------------JGC 

    if(413<= time && time<=419) %abril13-aril19
         DosesE2 =  2064;
         DosesE3 =  11693;
    elseif(420<=time && time<427) %Abril 20 - Abril27
         DosesE2 =  1888;
         DosesE3 =  10693;
    elseif(427<=time && time<= 434) %Abril 28 - Mayo4 en Adelante
         DosesE2 =  1424;
         DosesE3 =  8064;
    elseif(435<=time && time<= 441) %Mayo 5 - Mayo11 en Adelante
         DosesE2 =  1118;
         DosesE3 =  6339;
    elseif(442<=time && time <=448) %Mayo12-Mayo 18
         DosesE2 =  1383;
         DosesE3 =  7842;
    elseif(449<=time && time<=455)  %Mayo19-Mayo 25
         DosesE2 =  3120;
         DosesE3 =  17684; 
    elseif(456<=time && time<=463)  %Mayo 26 -Junio 2 
         DosesE2 =  3103;
         DosesE3 =  17584; 
    elseif(464<=time && time<=469)  %Junio 3 - Junio 8
         DosesE2 =  4440;
         DosesE3 =  25160; 
    elseif(470<=time && time<=476)  %Junio 9 - Junio 15
         DosesE2 =  4076;
         DosesE3 =  23098; 
    elseif(477<=time && time<=483)  %Junio 16 - Junio 22
         DosesE2 =  2704;
         DosesE3 =  15322; 
    elseif(484<=time && time<=490)  %Junio 23 - Junio 29
         DosesE2 =  1998;
         DosesE3 =  11323;
    elseif(491<=time && time<=497)  %Junio 30 - Julio 6
         DosesE2 =  1620;
         DosesE3 =  9186; 
    elseif(498<= time && time<=503)  %Julio7 - Julio 13
         DosesE2 =  1694;
         DosesE3 =  9603; 
   elseif(504<= time && time<=510)  %Julio14 - Julio27
         DosesE2 =  4253;
         DosesE3 =  24103; 
   elseif(511<= time && time<=517)  %Julio20 - Agosto2
         DosesE2 =  7928;
         DosesE3 =  44925;
   elseif(518<= time && time<=522)  %Julio28 -Agosto2
         DosesE2 =  4730;
         DosesE3 =  26806;
   elseif(time>=523)  %Agosto2
         DosesE2 =  1950;
         DosesE3 =  11050;  
    end
    
    currentDay = t1 + time-1-IncubationPeriod;
        
    % Transmit disease
    newInfectedPeople = [];  % new Infected - national id
    newInfectedGraph  = [];  % new Infected - graph id
    possible = cat(2,neighContacts{idToGraph(SD+SU+SDH+SUH+SE>0),1:3});
    useMask  = randsample(2,N,true,[1-pUseMask pUseMask])-1;
    %%% CAMBIO
    if(numel(possible)>0)
        possible = uniqueLoc(possible);
    end

    %%% CAMBIO
    for j = possible                         % check people that has contact with E,D,U
        currInd = GraphIDtoNationID(j);
        %%% nuevo cambio (se agrego SV1(currInd) y SV2(currInd)
        if(SS(currInd)||SV1(currInd)||SV2(currInd))       % if still susceptible might get sick
           
            canton     = idToCounty(currInd);
            region     = canton2region(canton);
            sizeBubble = minmaxBubble(region,1)+randi(minmaxBubble(region,2)-minmaxBubble(region,1)+1,1)-1;%minmaxBubble
            chosenN0   = GraphIDtoNationID(neighContacts{j,1});
            if(numel(neighContacts{j,2})+numel(neighContacts{j,3}) <= sizeBubble)
                chosenN1 = GraphIDtoNationID(neighContacts{j,2});
                chosenN2 = GraphIDtoNationID(neighContacts{j,3});
            else
                elegible   = cat(2,neighContacts{j,2:3});
                chosenN    = randsample(elegible,sizeBubble);
                chosenN1   = GraphIDtoNationID(intersect(neighContacts{j,2},chosenN));
                chosenN2   = GraphIDtoNationID(intersect(neighContacts{j,3},chosenN));
            end 

                % distribution for people that use mask and apply social distancing
                useDist1 = randsample(2,numel(chosenN1),true,[1-pUseDist(canton) pUseDist(canton)])-1;
                useDist2 = randsample(2,numel(chosenN2),true,[1-pUseDist(canton) pUseDist(canton)])-1;
                % prob no infectarse por contactos de familia
                p1 = sum(SE(chosenN0)) + sum(SU(chosenN0)) + sum(SUH(chosenN0)) + coefDiagnosedContact*sum(SD(chosenN0)) + coefDiagnosedContact*sum(SDH(chosenN0));
                
                %%% Nuevo cambio - (ante estaba solo esta linea  risk =
                %%% (1-coefFam*p).^(coefMin*p1);)
                if(SS(currInd))
                    risk = (1-coefFam*p).^(coefMin*p1);
                elseif(SV1(currInd))
                    risk = (1-coefFam*pv1).^(coefMin*p1);
                elseif(SV2(currInd))
                    risk = (1-coefFam*pv2).^(coefMin*p1);
                end
                
                % prob no infectarse por contactos conocidos
                p4 = chosenN1(logical(useMask(chosenN1).*useDist1)); % gente de chosenN1 que usan ambas
                p2 = setdiffLoc(chosenN1(logical(useMask(chosenN1))),p4); % gente de chosenN1 que usan solo mascarilla
                p3 = setdiffLoc(chosenN1(logical(useDist1)),p4); % gente de chosenN1 que usan solo distanciamiento
                p5 = setdiffLoc(chosenN1,[p2 p3 p4]);
                
                %%%Nuevo cambio- (antes estaba solo la linea
                %%% risk = risk*(1-coefMasc).^(coefMin*numel(p2))*(1-coefDist).^(coefMin*numel(p3))*(1-coefMD).^(coefMin*numel(p4))*(1-p).^(coefMin*numel(p5));
                if(SS(currInd))
                    risk = risk*(1-coefMasc).^(coefMin*numel(p2))*(1-coefDist).^(coefMin*numel(p3))*(1-coefMD).^(coefMin*numel(p4))*(1-p).^(coefMin*numel(p5));
                elseif(SV1(currInd))
                    risk = risk*(1-0.45*pv1).^(coefMin*numel(p2))*(1-0.45*pv1).^(coefMin*numel(p3))*(1-0.45*pv1).^(coefMin*numel(p4))*(1-pv1).^(coefMin*numel(p5));
                elseif(SV2(currInd))
                    risk = risk*(1-0.45*pv2).^(coefMin*numel(p2))*(1-0.45*pv2).^(coefMin*numel(p3))*(1-0.45*pv2).^(coefMin*numel(p4))*(1-pv2).^(coefMin*numel(p5));
                end
                
                % prob no infectarse por esporádicos
                p4 = chosenN2(logical(useMask(chosenN2).*useDist2)); % gente de chosenN1 que usan ambas
                p2 = setdiffLoc(chosenN2(logical(useMask(chosenN2))),p4); % gente de chosenN1 que usan solo mascarilla
                p3 = setdiffLoc(chosenN2(logical(useDist2)),p4); % gente de chosenN1 que usan solo distanciamiento
                p5 = setdiffLoc(chosenN2,[p2 p3 p4]);
                
                %%% nuevo cambio-- antes estaba solo esta linea
                %%% risk = risk*(1-coefSpor*coefMasc).^(coefMin*numel(p2))*(1-coefSpor*coefDist).^(coefMin*numel(p3))*(1-coefSpor*coefMD).^(coefMin*numel(p4))*(1-coefSpor*p).^(coefMin*numel(p5));
                if(SS(currInd))
                    risk = risk*(1-coefMasc).^(coefMin*numel(p2))*(1-coefDist).^(coefMin*numel(p3))*(1-coefMD).^(coefMin*numel(p4))*(1-p).^(coefMin*numel(p5));
                elseif(SV1(currInd))
                    risk = risk*(1-0.45*pv1).^(coefMin*numel(p2))*(1-0.45*pv1).^(coefMin*numel(p3))*(1-0.45*pv1).^(coefMin*numel(p4))*(1-pv1).^(coefMin*numel(p5));
                elseif(SV2(currInd))
                    risk = risk*(1-0.45*pv2).^(coefMin*numel(p2))*(1-0.45*pv2).^(coefMin*numel(p3))*(1-0.45*pv2).^(coefMin*numel(p4))*(1-pv2).^(coefMin*numel(p5));
                end
                
                % prob infección
                risk = 1 - risk;
                infected = randsample(2,1,true,[1-risk, risk])-1;
                if(infected)
                    newInfectedPeople = [newInfectedPeople, currInd]; %#ok<*AGROW>
                    newInfectedGraph =  [newInfectedGraph, j];
                end
        end
    end
    
    initInfectedPeople = newInfectedPeople;
    initInfectedGraph = newInfectedGraph;

    % number of new infected people so we include all of its contacts
    n = numel(initInfectedPeople);
    % Update graph with new people
    for j = 1:n
        % Step 1: include family for new infecteded people; add if not in graph
        % current individual
        currInd = initInfectedPeople(j);     % global id
        currIndGraph = initInfectedGraph(j);  % local id
        % find family and include new nodes for new found families
        numFamily   = idToFamily(currInd);
        if(~familyAdded(numFamily))
            % ids for family
            familyNodes = familyAccum(numFamily)+1:familyAccum(numFamily+1);
            % remove nodes already in the graph
            nodesToAdd = familyNodes(notadded(familyNodes));
            % update added
            notadded(nodesToAdd) = false;
            GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
            idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
            numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
            % list all family edges (graph number of nodes)
            allEdges = combnk(idToGraph(familyNodes),2);
            % mark family as added
            familyAdded(numFamily)= true;
            % update neighborhs
            for m = 1:size(allEdges,1)
                neighContacts{allEdges(m,1),1}(end+1) = allEdges(m,2);
                neighContacts{allEdges(m,2),1}(end+1) = allEdges(m,1);
            end
        end
        
        % STEP 3: include known contacts
        % determine number of new connections
        newConnections = max(0,degreeContacts(currInd)-numel(neighContacts{currIndGraph,2}));
        if(newConnections>0)
            % who is eligible
            %elegiblesW = pickCoworkers(3*newConnections,cumsum_people_per_county,nearCounties{idToCounty(currInd)},density_per_county);
            population = selectPeople{idToCounty(currInd)};
            elegiblesW = population(randi(numel(population),1,3*newConnections)); %nuevo
            elegiblesW = setdiffLoc(elegiblesW, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
            newCoworkers = elegiblesW(randperm(numel(elegiblesW),newConnections));
            % find preexisting nodes on the graph
            nodesToAdd = newCoworkers(notadded(newCoworkers));
            % update added
            notadded(nodesToAdd) = false;
            % keep track of order of nodes
            GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
            idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
            numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
            % add edges
            allEdges = idToGraph(newCoworkers);
            % update neighborhs
            neighContacts{currIndGraph,2}(end+1:end+numel(allEdges)) = allEdges;
            for m = 1:numel(allEdges)
                neighContacts{allEdges(m),2}(end+1) = currIndGraph;
            end
        end
        
        % STEP 4: include sporadic contacts
        % number of sporadic contacts
        newConnections = max(0,degreeSporadic(currInd)-numel(neighContacts{currIndGraph,3})); %countContacts(row,5);
        if(newConnections>0)
            % who is eligible
            %elegiblesF = pickCoworkers(3*newConnections,cumsum_people_per_county,nearCounties{idToCounty(currInd)},density_per_county);
            population = selectPeople{idToCounty(currInd)};
            elegiblesF = population(randi(numel(population),1,3*newConnections)); %nuevo
            elegiblesF = setdiffLoc(elegiblesF, [currInd GraphIDtoNationID(neighContacts{currIndGraph,1}) GraphIDtoNationID(neighContacts{currIndGraph,2}) GraphIDtoNationID(neighContacts{currIndGraph,3})]);
            newFriends   = elegiblesF(randperm(numel(elegiblesF),newConnections));
            % find preexisting nodes on the graph
            nodesToAdd = newFriends(notadded(newFriends));
            % update added
            notadded(nodesToAdd) = false;
            % keep track of order of nodes
            GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
            idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
            numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
            % add edges
            allEdges = idToGraph(newFriends);
            % update neighborhs
            neighContacts{currIndGraph,3}(end+1:end+numel(allEdges)) = allEdges;
            for m = 1:numel(allEdges)
                neighContacts{allEdges(m),3}(end+1) = currIndGraph;
            end
        end
    end
   
    % new S->E
    SS(newInfectedPeople) = false;
    SV1(newInfectedPeople) = false;
    SV2(newInfectedPeople) = false;
    SE(newInfectedPeople) = true;
    % save time so they can recover eventually
    timeCompartmentE(newInfectedPeople)  = currentDay;
    timeCompartmentV1(newInfectedPeople) = Inf;
    timeCompartmentV2(newInfectedPeople) = Inf;
    
    % E -> D, E -> U
    index = currentDay-timeCompartmentE == IncubationPeriod;
    if(sum(index)>0)
        index = find(index);
        ages  = idToAge(index);
        i1    = (ages==1).*(index);
        i1    = i1(i1>0);           % D and U
        i2    = (ages==2).*(index);
        i2    = i2(i2>0);           % D and U
        i3    = (ages==3).*(index);
        i3    = i3(i3>0);           % D and U
        randOrder     = randperm(numel(i1));
        splitPosition = ceil(numel(i1)*RatioDiagnosedOverInfected);
        indexD1 = i1(randOrder(1:splitPosition));%intersect(DiagnosedClass,i1);
        indexU1 = i1(randOrder(splitPosition+1:end));%intersect(DiagnosedClass,i2);
        randOrder = randperm(numel(i2));
        splitPosition = ceil(numel(i2)*RatioDiagnosedOverInfected);
        indexD2 = i2(randOrder(1:splitPosition));%intersect(DiagnosedClass,i1);
        indexU2 = i2(randOrder(splitPosition+1:end));%intersect(DiagnosedClass,i2);
        randOrder = randperm(numel(i3));
        splitPosition = ceil(numel(i3)*RatioDiagnosedOverInfected);
        indexD3 = i3(randOrder(1:splitPosition));%intersect(DiagnosedClass,i1);
        indexU3 = i3(randOrder(splitPosition+1:end));%intersect(DiagnosedClass,i2);
        
        indexD1V = indexD1(Vac(indexD1)); %JG0622
        indexD2V = indexD2(Vac(indexD2)); %JG0622
        indexD3V = indexD3(Vac(indexD3)); %JG0622
        indexD1 = setdiff(indexD1,indexD1V); %JG0622
        indexD2 = setdiff(indexD2,indexD2V); %JG0622
        indexD3 = setdiff(indexD3,indexD3V); %JG0622
        
        requireHfromD1 = indexD1(logical(randsample(2,numel(indexD1),true,[1-PercDiagnosedToHospital_G1, PercDiagnosedToHospital_G1])-1)); % 1 if D will require H at day 4
        requireHfromD2 = indexD2(logical(randsample(2,numel(indexD2),true,[1-PercDiagnosedToHospital_G2, PercDiagnosedToHospital_G2])-1)); % 1 if D will require H at day 4
        requireHfromD3 = indexD3(logical(randsample(2,numel(indexD3),true,[1-PercDiagnosedToHospital_G3, PercDiagnosedToHospital_G3])-1)); % 1 if D will require H at day 4
        
        requireHfromD1V = indexD1V(logical(randsample(2,numel(indexD1V),true,[1-PercDiagnosedToHospital_G1_V, PercDiagnosedToHospital_G1_V])-1)); %JG0622
        requireHfromD2V = indexD2V(logical(randsample(2,numel(indexD2V),true,[1-PercDiagnosedToHospital_G2_V, PercDiagnosedToHospital_G2_V])-1)); %JG0622
        requireHfromD3V = indexD3V(logical(randsample(2,numel(indexD3V),true,[1-PercDiagnosedToHospital_G3_V, PercDiagnosedToHospital_G3_V])-1)); %JG0622
        
        requireHfromU1 = indexU1(logical(randsample(2,numel(indexU1),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        requireHfromU2 = indexU2(logical(randsample(2,numel(indexU2),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        requireHfromU3 = indexU3(logical(randsample(2,numel(indexU3),true,[1-PercUndiagnosedToHospital, PercUndiagnosedToHospital])-1)); % 1 if U will require H at day 4
        
        willDiefromD1 = indexD1(logical(randsample(2,numel(indexD1),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromD2 = indexD2(logical(randsample(2,numel(indexD2),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromD3 = indexD3(logical(randsample(2,numel(indexD3),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        
        willDiefromU1 = indexU1(logical(randsample(2,numel(indexU1),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromU2 = indexU2(logical(randsample(2,numel(indexU2),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        willDiefromU3 = indexU3(logical(randsample(2,numel(indexU3),true,[1-0.0008, 0.0008])-1)); % 1 if D will require H at day 4
        
        willDiefromD1 = setdiffLoc(willDiefromD1,requireHfromD1);
        willDiefromD2 = setdiffLoc(willDiefromD2,requireHfromD2);
        willDiefromD3 = setdiffLoc(willDiefromD3,requireHfromD3);
        
        willDiefromU1 = setdiffLoc(willDiefromU1,requireHfromU1);
        willDiefromU2 = setdiffLoc(willDiefromU2,requireHfromU2);
        willDiefromU3 = setdiffLoc(willDiefromU3,requireHfromU3);
        
        noRequireHfromD1 = setdiffLoc(indexD1,[requireHfromD1 willDiefromD1]);
        noRequireHfromD2 = setdiffLoc(indexD2,[requireHfromD2 willDiefromD2]);
        noRequireHfromD3 = setdiffLoc(indexD3,[requireHfromD3 willDiefromD3]);
        
        noRequireHfromD1V = setdiffLoc(indexD1V, requireHfromD1V);
        noRequireHfromD2V = setdiffLoc(indexD2V, requireHfromD2V);
        noRequireHfromD3V = setdiffLoc(indexD3V, requireHfromD3V);
        
        noRequireHfromU1 = setdiffLoc(indexU1,[requireHfromU1 willDiefromU1]);
        noRequireHfromU2 = setdiffLoc(indexU2,[requireHfromU2 willDiefromU2]);
        noRequireHfromU3 = setdiffLoc(indexU3,[requireHfromU3 willDiefromU3]);
        
        noRequireHfromD = [noRequireHfromD1 noRequireHfromD2 noRequireHfromD3 noRequireHfromD1V noRequireHfromD2V noRequireHfromD3V]; %JG0622
        %noRequireHfromD = [noRequireHfromD1 noRequireHfromD2 noRequireHfromD3];
        noRequireHfromU = [noRequireHfromU1 noRequireHfromU2 noRequireHfromU3];
        requireHfromD   = [requireHfromD1 requireHfromD2 requireHfromD3 requireHfromD1V requireHfromD2V requireHfromD3V]; %JG0622
        %requireHfromD   = [requireHfromD1 requireHfromD2 requireHfromD3];
        requireHfromU   = [requireHfromU1 requireHfromU2 requireHfromU3];
        willDiefromD    = [willDiefromD1 willDiefromD2 willDiefromD3];
        willDiefromU    = [willDiefromU1 willDiefromU2 willDiefromU3];
        % save changes compartiment
        SE(index)  = false;
        SD(noRequireHfromD) = true;
        SU(noRequireHfromU) = true;
        SDH(requireHfromD)  = true;
        SUH(requireHfromU)  = true;
        SDD(willDiefromD)   = true;
        SUD(willDiefromU)   = true;
        % save time
        timeCompartmentD(noRequireHfromD) = currentDay;
        timeCompartmentU(noRequireHfromU) = currentDay;
        timeCompartmentDH(requireHfromD)  = currentDay;
        timeCompartmentUH(requireHfromU)  = currentDay;
        timeCompartmentDD(willDiefromD)   = currentDay;
        timeCompartmentUD(willDiefromU)   = currentDay;
        indexD = [indexD1 indexD2 indexD3];
    else
        indexD = []; % to compute accumD
    end
    
    newH = []; % JG0816
    % check UH -> H
    index = currentDay-timeCompartmentUH == DaysUndiagnosedToHospital;
    if(sum(index)>0)
        SUH(index) = false;
        SH(index)  = true;
        timeCompartmentH(index) = currentDay;
        newH = [newH find(index)]; % JG0816
    end
    
    % check DH -> H
    index = currentDay-timeCompartmentDH == DaysDiagnosedToHospital;
    if(sum(index)>0)
        SDH(index) = false;
        SH(index)  = true;
        timeCompartmentH(index) = currentDay;
        newH = [newH find(index)]; % JG0816
    end
    
    index = currentDay-timeCompartmentUD == 10;
    if(sum(index)>0)
        SUD(index)   = false;
        SDead(index) = true;
    end
    
    index = currentDay-timeCompartmentDD == 10;
    if(sum(index)>0)
        SDD(index)   = false;
        SDead(index) = true;
    end
    
    % check for recoveries D -> R
    index = currentDay-timeCompartmentD == DaysToRecoverDiagnosed;
    SR(index) = true;
    SD(index) = false;
    timeCompartmentR(index) = currentDay;
    
    % check for recoveries U -> R
    index     = currentDay-timeCompartmentU == DaysToRecoverUndiagnosed;
    SR(index) = true;
    SU(index) = false;
    timeCompartmentR(index) = currentDay;
    
    % check H -> UCI
    index = currentDay-timeCompartmentH == DaysHtoUCI;
    if(sum(index)>0)
        index = find(index);
        ages = idToAge(index);
        i1 = (ages==1).*(index);
        i1 = i1(i1>0);           % D and U
        i2 = (ages==2).*(index);
        i2 = i2(i2>0);           % D and U
        i3 = (ages==3).*(index);
        i3 = i3(i3>0);           % D and U
        HtoUCI1 = i1(logical(randsample(2,numel(i1),true,[1-PercHtoUCI_G1, PercHtoUCI_G1])-1)); % 1 if goes to UCI
        HtoUCI2 = i2(logical(randsample(2,numel(i2),true,[1-PercHtoUCI_G2, PercHtoUCI_G2])-1)); % 1 if goes to UCI
        HtoUCI3 = i3(logical(randsample(2,numel(i3),true,[1-PercHtoUCI_G3, PercHtoUCI_G3])-1)); % 1 if goes to UCI
        HtoUCI = [HtoUCI1 HtoUCI2 HtoUCI3];
        SH(HtoUCI)   = false;
        SUCI(HtoUCI) = true;
        % save time
        timeCompartmentUCI(HtoUCI) = currentDay;
        timeCompartmentH(HtoUCI)   = Inf;
    else
        HtoUCI1 = []; % JG0816
        HtoUCI2 = []; % JG0816
        HtoUCI3 = []; % JG0816
    end
    
    % check H -> R or dead
    index = currentDay-timeCompartmentH == DaysHospitalized_G1; % people with 14 days in H goes to R
    if(sum(index)>0)             % find people group age 1
        index = find(index);     % nationalID people with 14 days in H
        ages  = idToAge(index);  % age of all people with 14 days in H
        index = (ages==1).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        HtoR  = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G1, PercHtoR_G1])-1)); % 1 if recovers
        Hdies = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        timeCompartmentR(HtoR)  = currentDay;
        timeCompartmentH(index) = Inf;
    end
    index = currentDay-timeCompartmentH == DaysHospitalized_G2; % people with 14 days in H goes to R
    if(sum(index)>0)             % find people group age 1
        index = find(index);     % nationalID people with 14 days in H
        ages  = idToAge(index);  % age of all people with 14 days in H
        index = (ages==2).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        HtoR  = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G2, PercHtoR_G2])-1)); % 1 if recovers
        Hdies = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        timeCompartmentH(index) = Inf;
        timeCompartmentR(HtoR)  = currentDay;
    end
    index = currentDay-timeCompartmentH == DaysHospitalized_G3; % people with 14 days in H goes to R
    if(sum(index)>0)            % find people group age 1
        index = find(index);    % nationalID people with 14 days in H
        ages  = idToAge(index);  % age of all people with 14 days in H
        index = (ages==3).*(index);
        index = index(index>0);          % people on group 1 with 14 days in H
        HtoR  = index(logical(randsample(2,numel(index),true,[1-PercHtoR_G3, PercHtoR_G3])-1)); % 1 if recovers
        Hdies = setdiffLoc(index,HtoR);
        SDead(Hdies) = true;
        SR(HtoR)     = true;
        SH(index)    = false;
        timeCompartmentH(index) = Inf;
        timeCompartmentR(HtoR)  = currentDay;
    end
    
    % check UCI -> R or dead
    index = currentDay-timeCompartmentUCI == DaysUCI_G1;
    if(sum(index)>0)
        index    = find(index);
        ages     = idToAge(index);
        index    = (ages==1).*(index);
        index    = index(index>0);          % people on group 1 with 14 days in H
        UCItoR   = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G1, PercUCIrecovers_G1])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        timeCompartmentR(UCItoR)  = currentDay;
    end
    index = currentDay-timeCompartmentUCI >= DaysUCI_G2;
    if(sum(index)>0)
        index    = find(index);
        ages     = idToAge(index);
        index    = (ages==2).*(index);
        index    = index(index>0);          % people on group 1 with 14 days in H
        UCItoR   = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G2, PercUCIrecovers_G2])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        timeCompartmentR(UCItoR) = currentDay;
    end
    index = currentDay-timeCompartmentUCI >= DaysUCI_G3;
    if(sum(index)>0)
        index  = find(index);
        ages   = idToAge(index);
        index  = (ages==3).*(index);
        index  = index(index>0);          % people on group 1 with 14 days in H
        UCItoR = index(logical(randsample(2,numel(index),true,[1-PercUCIrecovers_G3, PercUCIrecovers_G3])-1)); % 1 if recovers
        UCIdies  = setdiffLoc(index,UCItoR);
        SDead(UCIdies) = true;
        SR(UCItoR)     = true;
        SUCI(index)    = false;
        timeCompartmentUCI(index) = Inf;
        timeCompartmentR(UCItoR) = currentDay;
    end
    
    
    %%%-------------------nuevas transiciones----------------------------------
    %S->V1, RR->V1
    if(time>=vaccineTime)
        Rem     = RR.*~Vac;  %JG0622
        index1  = find(SS);                     %encontramos personas susceptibles
        %index2  = find(RR); %JG0622
        index2  = find(Rem); %JG0622
        index   = [index1' index2'];
        index   = setdiff(index,noSeVacunan); % removemos gente que no se vacuna %JG0809


        ages  = idToAge(index);
        i1    = (ages==1).*(index);
        i1    = i1(i1>0);
        i2    = (ages==2).*(index);
        i2    = i2(i2>0);
        i3    = (ages==3).*(index);
        i3    = i3(i3>0);

        if(length(i3)>=DosesE3)
            StoVE3 = randsample(i3, DosesE3); % adulto mayor vacunado por dia
        else
            DosesE2 = DosesE2+DosesE3;
            StoVE3  = [];
            if(firstTimeE3 == 1)
                StoVE3  = i3;
                firstTimeE3=0; 
            end
        end
        
        if(length(i2)>=DosesE2)
            StoVE2 = randsample(i2, DosesE2); % adulto mayor vacunado por dia
        else
            DosesE1= DosesE2;
            StoVE3 = [];
            StoVE2 = [];
            if(firstTimeE2 == 1)
                StoVE2  = i2;
                firstTimeE2=0; 
            end
             
            faltan = length(i1)-(1486794-TotalVacE1);
            if(DosesE1<=faltan)
                StoVE1 = randsample(i1, DosesE1); % adulto mayor vacunado por dia
            elseif(firstTimeE1 == 1)
                StoVE1     =  randsample(i1, faltan);
                firstTimeE1=0; 
            else
                 StoVE3 = [];
                 StoVE2 = [];
                 StoVE1 = [];
            end
        end
        
        StoV1        = [StoVE1 StoVE2 StoVE3];    %Total Vacunados
        Vac(StoV1)   = true; %JG0622
        SV1(StoV1)   = true;     %Vacunados entran en un estado V pero siguen siendo susceptibles
        SS(StoV1)    = false;
        RR(StoV1)    = false;
        timeCompartmentV1(StoV1) = currentDay;  %save time
    else
        StoV1  = [];
        StoVE1 = [];
        StoVE2 = [];
        StoVE3 = [];
    end
    
    %V1->V2  %Removemos los vacunados del compartimento de los susceptibles
    index = currentDay-timeCompartmentV1 == TimeSV;
    if(sum(index)>0)
        SV1(index) = false;
        SV2(index) = true;                %Personas vacunadas
        timeCompartmentV2(index) = currentDay;
        timeCompartmentV1(index) = Inf;
        index = find(index);
        ages  = idToAge(index);
        i1    = (ages==1).*(index);
        StoV2E1    = i1(i1>0);
        i2    = (ages==2).*(index);
        StoV2E2    = i2(i2>0);
        i3    = (ages==3).*(index);
        StoV2E3    = i3(i3>0);
        StoV2 = [StoV2E1 StoV2E2 StoV2E3];
    else
        StoV2 = [];
        StoV2E1 = [];
        StoV2E2 = [];
        StoV2E3 = [];
    end
    
    %R->S (Despues de 90 días las personas infectadas pueden ser elegibles a ser vacunados)
    
    index = currentDay-timeCompartmentR == ImmunityTimeR;
    if(sum(index)>0)
        SR(index)=false;
        RR(index)=true;
        timeCompartmentR(index)=Inf;
    end
    
    %%%--------------------------------------------------------------------
    
    % update
    
    iu    = (SU==1|SUH==1|SUD==1)';
    id    = (SD==1|SDH==1|SDD==1)';
    ih    = (SH==1)';
    iuci  = (SUCI==1)';
    idead = (SDead==1)';
    iV1   = (SV1==1)';  %vaccine
    iV2   = (SV2==1)';  %vaccine
    % update
    totalH(time+1)    = sum(SH);
    totalUCI(time+1)  = sum(SUCI);
    totalD(time+1)    = sum(SD)+sum(SDH)+sum(SDD);
    totalU(time+1)    = sum(SU)+sum(SUH)+sum(SUD);
    totalDead(time+1) = sum(SDead);
    totalS(time+1) = sum(SS);
    totalE(time+1) = sum(SE);
    totalR(time+1) = sum(SR);
    totalRR(time+1) = sum(RR);

    totalV1(time+1)   = sum(SV1);   %%%%%%%%%%-----Guardar los vacunados con una dosis --------
    totalV2(time+1)   = sum(SV2);  %%%%%%%%%%-----Guardar los vacunados con dos dosis --------
    accumD(time+1)    = accumD(time) + numel(indexD);
    accumV1(time+1)   = accumV1(time) + numel(StoV1); % JG20712
    accumV1E1(time+1) = accumV1E1(time) + numel(StoVE1); % JG20712
    accumV1E2(time+1) = accumV1E2(time) + numel(StoVE2); % JG20712
    accumV1E3(time+1) = accumV1E3(time) + numel(StoVE3); % JG20712
    accumV2(time+1)   = accumV2(time)   + numel(StoV2); % JG20712
    accumV2E1(time+1) = accumV2E1(time) + numel(StoV2E1);
    accumV2E2(time+1) = accumV2E2(time) + numel(StoV2E2);
    accumV2E3(time+1) = accumV2E3(time) + numel(StoV2E3);
    accumD1(time+1)   = accumD1(time) + sum(idToAge(indexD)==1); % JG0816
    accumD2(time+1)   = accumD2(time) + sum(idToAge(indexD)==2); % JG0816
    accumD3(time+1)   = accumD3(time) + sum(idToAge(indexD)==3); % JG0816
    nuevosUCI1(time+1)= numel(HtoUCI1); % JG0816
    nuevosUCI2(time+1)= numel(HtoUCI2); % JG0816
    nuevosUCI3(time+1)= numel(HtoUCI3); % JG0816
    
    % salvar segun edad
    i1 = (idToAge==1);
    totalU1(time+1)    = sum(iu & i1);
    totalD1(time+1)    = sum(id & i1);
    totalH1(time+1)    = sum(ih & i1);
    totalUCI1(time+1)  = sum(iuci & i1);
    totalDead1(time+1) = sum(idead & i1);
    totalV1E1(time+1)  = sum(iV1 & i1);  %%vaccine
    totalV2E1(time+1)  = sum(iV2 & i1);  %%vaccine 
    
    i1 = (idToAge==2);
    totalU2(time+1)    = sum(iu & i1);
    totalD2(time+1)    = sum(id & i1);
    totalH2(time+1)    = sum(ih & i1);
    totalUCI2(time+1)  = sum(iuci & i1);
    totalDead2(time+1) = sum(idead & i1);
    totalV1E2(time+1)  = sum(iV1 & i1);  %%vaccine
    totalV2E2(time+1)  = sum(iV2 & i1);  %%vaccine 
    
    i1 = (idToAge==3);
    totalU3(time+1)    = sum(iu & i1);
    totalD3(time+1)    = sum(id & i1);
    totalH3(time+1)    = sum(ih & i1);
    totalUCI3(time+1)  = sum(iuci & i1);
    totalDead3(time+1) = sum(idead & i1);
    totalV1E3(time+1)  = sum(iV1 & i1);  %%vaccine
    totalV2E3(time+1)  = sum(iV2 & i1);  %%vaccine 
    
    age = idToAge(newH);            % JG0816
    nuevosH1(time+1) = sum(age==1); % JG0816
    nuevosH2(time+1) = sum(age==2); % JG0816
    nuevosH3(time+1) = sum(age==3); % JG0816
    
    if(countyInfo)
        dataMap(:,time) = hist(idToCounty(logical(SD+SDH)),1:81); % D
        del = hist(idToCounty(indexD),1:81)';
        dataMapAcum(:,time+1) = dataMapAcum(:,time)+del;
        % hospis y UCIs y muertes epor canton
        dataMapUCI(:,time+1) = hist(idToCounty(logical(SUCI)),1:81);
        dataMapH(:,time+1)   = hist(idToCounty(logical(SH)),1:81);
        dataMapMuertes(:,time+1) = hist(idToCounty(logical(SDead)),1:81);
        dataMapU(:,time+1)   = hist(idToCounty(logical(SU+SUH)),1:81);
    end
    
    if(time>380)
        tic
    end
    
    %disp([time (totalH(time+1)-totalH(time)) (totalUCI(time+1)-totalUCI(time))])
end

toc
export = zeros(T+1,48,'uint32');
export(:,1)  = accumD;
export(:,2)  = totalD;
export(:,3)  = totalH;
export(:,4)  = totalUCI;
export(:,5)  = totalDead;
export(:,6)  = totalU;
export(:,7)  = totalD1;
export(:,8)  = totalH1;
export(:,9)  = totalUCI1;
export(:,10) = totalDead1;
export(:,11) = totalU1;
export(:,12) = totalD2;
export(:,13) = totalH2;
export(:,14) = totalUCI2;
export(:,15) = totalDead2;
export(:,16) = totalU2;
export(:,17) = totalD3;
export(:,18) = totalH3;
export(:,19) = totalUCI3;
export(:,20) = totalDead3;
export(:,21) = totalU3;
export(:,22) = accumD1;
export(:,23) = accumD2;
export(:,24) = accumD3;
export(:,25) = totalV1;
export(:,26) = totalV2;
export(:,27) = totalV1E1;
export(:,28) = totalV1E2;
export(:,29) = totalV1E3;
export(:,30) = totalV2E1;
export(:,31) = totalV2E2;
export(:,32) = totalV2E3;
export(:,33) = accumV1;
export(:,34) = accumV1E1;
export(:,35) = accumV1E2;
export(:,36) = accumV1E3;
export(:,37) = accumV2;
export(:,38) = accumV2E1;
export(:,39) = accumV2E2;
export(:,40) = accumV2E3; 
export(:,41) = nuevosH1; % JG0816
export(:,42) = nuevosH2; % JG0816
export(:,43) = nuevosH3; % JG0816
export(:,44) = nuevosUCI1; % JG0816
export(:,45) = nuevosUCI2; % JG0816
export(:,46) = nuevosUCI3; % JG0816
export(:,47) = nuevosH1+nuevosH2+nuevosH3; % JG0816
export(:,48) = nuevosUCI1+nuevosUCI2+nuevosUCI3; % JG0816
end

function parsave(k,x,dir,nameFile)
nameFile = [dir '/' nameFile num2str(k) '.mat'];
save(nameFile, 'x')
end

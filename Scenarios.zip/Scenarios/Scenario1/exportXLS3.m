clear dir expo
direc = './info/';
simulations = 20;

nameFile1 = 'proy_';
nameFile2 = 'mapAct_';
nameFile3 = 'mapAcum_';
nameFile4 = 'mapUCI_';
nameFile5 = 'mapH_';
nameFile6 = 'mapMuertes_';
nameFile7 = 'mapU_';

nombre = nameFile1;
nombre2 = 'ind';

T = 330; % 165 217
t0 = datetime(2020,2,26); % first day in E class
days = (t0:t0+T);         % range of days
maxDay = T;%217; %

export1 = zeros(simulations,T+1,'uint32');
export2 = zeros(simulations,T+1,'uint32');
export3 = zeros(simulations,T+1,'uint32');
export4 = zeros(simulations,T+1,'uint32');
export5 = zeros(simulations,T+1,'uint32');
export6 = zeros(simulations,T+1,'uint32');

files1=dir(['./info/' nameFile1 '*.mat']);
files2=dir(['./info/' nameFile2 '*.mat']);
files3=dir(['./info/' nameFile3 '*.mat']);
files4=dir(['./info/' nameFile4 '*.mat']);
files5=dir(['./info/' nameFile5 '*.mat']);
files6=dir(['./info/' nameFile6 '*.mat']);
files7=dir(['./info/' nameFile7 '*.mat']);
simulations = size(files1,1);

for k = 1:simulations
    nameFile = [direc files1(k).name];
    tem = load(nameFile);
    tem = tem.x;
    export1(k,:) = tem(:,1);
    export2(k,:) = tem(:,2);
    export3(k,:) = tem(:,3);
    export4(k,:) = tem(:,4);
    export5(k,:) = tem(:,5);
    export6(k,:) = tem(:,6);
end

clear expo
expo(1,:) = sum(export1,1)/simulations;
expo(2,:) = sum(export2,1)/simulations;
expo(3,:) = sum(export3,1)/simulations;
expo(4,:) = sum(export4,1)/simulations;
expo(5,:) = sum(export5,1)/simulations;
expo(6,:) = sum(export6,1)/simulations;

% exportar promedios nacionales
TT = table(days',expo(1,:)',expo(2,:)',expo(3,:)',expo(4,:)', expo(5,:)',expo(6,:)');
writetable(TT,[nameFile1 '_datos_' date '.xlsx'],'Sheet',1)

% datos cantonales
dataMap = zeros(81,T);
dataMapAcum = zeros(81,T+1);
dataMapUCI = zeros(81,T+1);
dataMapH = zeros(81,T+1);
dataMapMuertes = zeros(81,T+1);
dataMapU = zeros(81,T+1);

for k = 1:simulations
    
    nameFile = [direc files2(k).name];
    x = load(nameFile);
    dataMap = dataMap + x.x;
    
    nameFile = [direc files3(k).name];
    x = load(nameFile);
    dataMapAcum = dataMapAcum + x.x;
    
    nameFile = [direc files4(k).name];
    x = load(nameFile);
    dataMapUCI = dataMapUCI + x.x;
    
    nameFile = [direc files5(k).name];
    x = load(nameFile);
    dataMapH = dataMapH + x.x;
    
    nameFile = [direc files6(k).name];
    x = load(nameFile);
    dataMapMuertes = dataMapMuertes + x.x;
    
    nameFile = [direc files7(k).name];
    x = load(nameFile);
    dataMapU = dataMapU + x.x;
end
dataMap = dataMap/simulations;
dataMapAcum = dataMapAcum/simulations;
dataMapUCI = dataMapUCI/simulations;
dataMapH = dataMapH/simulations;
dataMapMuertes = dataMapMuertes/simulations;
dataMapU = dataMapU/simulations;
% promedios
TT = table(days(2:end)',dataMap');
writetable(TT,[nombre '_datos_cantones_activos' date '.xlsx'],'Sheet',1)
TT = table(days(1:end)',dataMapAcum');
writetable(TT,[nombre '_datos_cantones_acumulados' date '.xlsx'],'Sheet',1)
TT = table(days(1:end)',dataMapUCI');
writetable(TT,[nombre '_datos_cantones_UCIs' date '.xlsx'],'Sheet',1)
TT = table(days(1:end)',dataMapH');
writetable(TT,[nombre '_datos_cantones_H' date '.xlsx'],'Sheet',1)
TT = table(days(1:end)',dataMapMuertes');
writetable(TT,[nombre '_datos_cantones_Muertes' date '.xlsx'],'Sheet',1)
TT = table(days(1:end)',dataMapU');
writetable(TT,[nombre '_datos_cantones_U' date '.xlsx'],'Sheet',1)

toStore1 = zeros(simulations,81,T);
toStore2 = zeros(simulations,81,T+1);
toStore3 = zeros(simulations,81,T+1);
toStore4 = zeros(simulations,81,T+1);
toStore5 = zeros(simulations,81,T+1);
toStore6 = zeros(simulations,81,T+1);

%rang = ['A' num2str(k) ':FO' num2str(k)];
%TT = table(x(j,:));
%writetable(TT,[nombre2 '_canton_Activos_.xlsx'],'Sheet',j,'Range',rang,'WriteVariableNames',false)

for j = 1:81
    for k = 1:simulations
        
        nameFile = [direc files2(k).name];
        x = load(nameFile);
        x = x.x;
        toStore1(k,j,:) = x(j,:);
        
        nameFile = [direc files3(k).name];
        x = load(nameFile);
        x = x.x;
        toStore2(k,j,:) = x(j,:);
        
        nameFile = [direc files4(k).name];
        x = load(nameFile);
        x = x.x;
        toStore3(k,j,:) = x(j,:);
        
        nameFile = [direc files5(k).name];
        x = load(nameFile);
        x = x.x;
        toStore4(k,j,:) = x(j,:);

        nameFile = [direc files6(k).name];
        x = load(nameFile);
        x = x.x;        
        toStore5(k,j,:) = x(j,:);

        nameFile = [direc files7(k).name];
        x = load(nameFile);
        x = x.x;
        toStore6(k,j,:) = x(j,:);
    end
    
    TT = table(toStore1(:,j,:));
    writetable(TT,[nombre2 '_canton_Activos_.xlsx'],'Sheet',j,'WriteVariableNames',false)
    
    TT = table(toStore2(:,j,:));
    writetable(TT,[nombre2 '_canton_Acum_.xlsx'],'Sheet',j,'WriteVariableNames',false)
    
    TT = table(toStore3(:,j,:));
    writetable(TT,[nombre2 '_canton_UCI_.xlsx'],'Sheet',j,'WriteVariableNames',false)
    
    TT = table(toStore4(:,j,:));
    writetable(TT,[nombre2 '_canton_H_.xlsx'],'Sheet',j,'WriteVariableNames',false)
    
    TT = table(toStore5(:,j,:));
    writetable(TT,[nombre2 '_canton_Muertes_.xlsx'],'Sheet',j,'WriteVariableNames',false)
    
    TT = table(toStore6(:,j,:));
    writetable(TT,[nombre2 '_canton_U_.xlsx'],'Sheet',j,'WriteVariableNames',false)
end
function vacunas()
vacunacion = readtable('BaseVacunas_1.xlsx');
i1 = vacunacion.Edad<=18;
i2 = vacunacion.Edad>18 & vacunacion.Edad<58;
i3 = vacunacion.Edad>=58;
% lleno cantones faltantes de forma aleatoria (Rio Cuarto -> Grecia)
canton = vacunacion.CC_JG;
canton(isnan(canton)) = randi(81,[sum(isnan(canton)) 1]);
% convierta fechas
fechaVac = vacunacion.FechaAplicaci_n;
fechaVac = datenum(fechaVac);
% fechas según el modelo
fechas = nan(numel(fechaVac),1);
time = 303; % 24 diciembre
% agrupe por fechas
for day = min(fechaVac):max(fechaVac)
    fechas(fechaVac == day) = time;
    time = time + 1;
end
index = vacunacion.Primera_Dosis==1;
infoVac = [fechas canton i1 i2 i3];
infoVac = infoVac(index,:);
save('infoVac','infoVac')
end
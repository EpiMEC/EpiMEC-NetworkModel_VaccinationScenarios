%new = [2 4; 3 19; 1 10; 1 28]; % county and number people

newFriends = [];
for j = 1:size(new,1)
    newFriends = [newFriends, pickFriends(new(j,1),new(j,2),cumsum_people_per_county)];
end

% check they are SS
while(sum(~SS(newFriends)>0))
    newFriends = [];
    for j = 1:size(new,1)
        newFriends = [newFriends, pickFriends(new(j,1),new(j,2),cumsum_people_per_county)];
    end
end

%elegiblesF = pickFriends(2,4,cumsum_people_per_county);
%elegiblesF = [elegiblesF, pickFriends(3,19,cumsum_people_per_county)];
%elegiblesF = [elegiblesF, pickFriends(1,10,cumsum_people_per_county)];
%elegiblesF = [elegiblesF, pickFriends(1,28,cumsum_people_per_county)];
%newFriends   = elegiblesF;
% find preexisting nodes on the graph
%nodesToAdd = newFriends(~ismember(newFriends,nodesGraph(1:indexNodesGraph)));
nodesToAdd = newFriends(notadded(newFriends));
% update added
notadded(nodesToAdd) = false; % add if = true
% add nodes
if(createGraph)
    G = addnode(G,numel(nodesToAdd));
end
% add cells for new nodes noeghbors
for m = 1:numel(nodesToAdd)
    neighContacts{end+1,1} = [];
    neighContacts{end,2} = [];
    neighContacts{end,3} = [];
end
% keep track of order of nodes
GraphIDtoNationID(numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd)) = nodesToAdd;
idToGraph(nodesToAdd) = numberNodesGraph+1:numberNodesGraph+numel(nodesToAdd);
numberNodesGraph = numberNodesGraph + numel(nodesToAdd);
newInfectedPeople = [newInfectedPeople, newFriends]; %#ok<*AGROW>
newInfectedGraph =  [newInfectedGraph; (numberNodesGraph-numel(newFriends)+1:numberNodesGraph)'];
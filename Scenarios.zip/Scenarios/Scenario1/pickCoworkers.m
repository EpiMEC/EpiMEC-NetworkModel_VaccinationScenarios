function people = pickCoworkers(NCoworkers,cumsum_people_per_county,nearCounties,dens)
    range = [];
    %p = [];
    for j = nearCounties
        newrange = cumsum_people_per_county(j)+1:cumsum_people_per_county(j+1);
        range = [range, newrange];
        %p = [p, dens(j)*ones(size(newrange))];
    end
    people = randsample(range,NCoworkers);
    %people = randsample(range,NCoworkers,true,p);
end
function  nearCounties = computeNearCounties(trigger,dir)
nearCounties = cell(81,1);
counties_order_Work_to_Fam = xlsread([dir 'ConectividadCantones'],'ReordenarCantones','B1:B81');
workers_by_county = xlsread([dir 'ConectividadCantones'],'TrabajadoresPorCanton','A1:CC81');
workers_by_county = workers_by_county(counties_order_Work_to_Fam,counties_order_Work_to_Fam);
workers_by_county = workers_by_county./sum(workers_by_county,2); % normalize
% precompute info
for j = 1:81
    nearCounties{j} = find(workers_by_county(j,:)>trigger);
end

end
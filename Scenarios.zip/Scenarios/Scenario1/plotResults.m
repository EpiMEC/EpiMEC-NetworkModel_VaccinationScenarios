function plotResults()
clear dir expo
direc = './info/';

nameFile1 = 'proy_';
nameFile2 = 'mapAct_';
nameFile3 = 'mapAcum_';
nameFile4 = 'mapUCI_';
nameFile5 = 'mapH_';
nameFile6 = 'mapMuertes_';
nameFile7 = 'mapU_';
num_cbg = 81;
nombre  = nameFile1;
nombre1 = './Plots/';

T    = 674; % 165 217
t0   = datetime(2020,2,26); % first day in E class
days = (t0:t0+T);          % range of days

maxDay = T;%217; % 

saveFigure = true;

files=dir(['./info/' nameFile1 '*.mat']);
sim = size(files,1);

export1 = zeros(sim,T+1,'uint32');
export2 = zeros(sim,T+1,'uint32');
export3 = zeros(sim,T+1,'uint32');
export4 = zeros(sim,T+1,'uint32');
export5 = zeros(sim,T+1,'uint32');
export6 = zeros(sim,T+1,'uint32');
export7 = zeros(sim,T+1,'uint32');
export8 = zeros(sim,T+1,'uint32');
export9 = zeros(sim,T+1,'uint32');
export10 = zeros(sim,T+1,'uint32');
export11 = zeros(sim,T+1,'uint32');
export12 = zeros(sim,T+1,'uint32');
export13 = zeros(sim,T+1,'uint32');
export14 = zeros(sim,T+1,'uint32');
export15 = zeros(sim,T+1,'uint32');
export16 = zeros(sim,T+1,'uint32');
export17 = zeros(sim,T+1,'uint32');
export18 = zeros(sim,T+1,'uint32');
export19 = zeros(sim,T+1,'uint32');
export20 = zeros(sim,T+1,'uint32');
export21 = zeros(sim,T+1,'uint32');
export22 = zeros(sim,T+1,'uint32');
export23 = zeros(sim,T+1,'uint32');
export24 = zeros(sim,T+1,'uint32');
export25 = zeros(sim,T+1,'uint32');
export26 = zeros(sim,T+1,'uint32');
export27 = zeros(sim,T+1,'uint32');
export28 = zeros(sim,T+1,'uint32');
export29 = zeros(sim,T+1,'uint32');
export30 = zeros(sim,T+1,'uint32');
export31 = zeros(sim,T+1,'uint32');
export32 = zeros(sim,T+1,'uint32');
export33 = zeros(sim,T+1,'uint32');
export34 = zeros(sim,T+1,'uint32');
export35 = zeros(sim,T+1,'uint32');
export36 = zeros(sim,T+1,'uint32');
export37 = zeros(sim,T+1,'uint32');
export38 = zeros(sim,T+1,'uint32');
export39 = zeros(sim,T+1,'uint32');
export40 = zeros(sim,T+1,'uint32');
export41 = zeros(sim,T+1,'uint32'); %nuevosH1; % JG0816
export42 = zeros(sim,T+1,'uint32'); %nuevosH2; % JG0816
export43 = zeros(sim,T+1,'uint32'); %nuevosH3; % JG0816
export44 = zeros(sim,T+1,'uint32'); %nuevosUCI1; % JG0816
export45 = zeros(sim,T+1,'uint32'); %nuevosUCI2; % JG0816
export46 = zeros(sim,T+1,'uint32'); %nuevosUCI3; % JG0816
export47 = zeros(sim,T+1,'uint32'); %nuevosH1+nuevosH2+nuevosH3; % JG0816
export48 = zeros(sim,T+1,'uint32'); %nuevosUCI1+nuevosUCI2+nuevosUCI3; % JG0816

for k = 1:sim
    %nameFile = [direc '/' nameFile1 num2str(k) '.mat'];
    nameFile = [direc files(k).name];
    tem = load(nameFile);
    tem = tem.x;

    export1(k,:) = tem(:,1);
    export2(k,:) = tem(:,2);
    export3(k,:) = tem(:,3);
    export4(k,:) = tem(:,4);
    export5(k,:) = tem(:,5);
    export6(k,:) = tem(:,6);
    export7(k,:) = tem(:,7);
    export8(k,:) = tem(:,8);
    export9(k,:) = tem(:,9);
    export10(k,:) = tem(:,10);
    export11(k,:) = tem(:,11);
    export12(k,:) = tem(:,12);
    export13(k,:) = tem(:,13);
    export14(k,:) = tem(:,14);
    export15(k,:) = tem(:,15);
    export16(k,:) = tem(:,16);
    export17(k,:) = tem(:,17);
    export18(k,:) = tem(:,18);
    export19(k,:) = tem(:,19);
    export20(k,:) = tem(:,20);
    export21(k,:) = tem(:,21);
    export22(k,:) = tem(:,22);
    export23(k,:) = tem(:,23);
    export24(k,:) = tem(:,24);    %parsave(sim,dataMap,dir,nameFile);
    export25(k,:) = tem(:,25);
    export26(k,:) = tem(:,26);
    export27(k,:) = tem(:,27);
    export28(k,:) = tem(:,28);
    export29(k,:) = tem(:,29);
    export30(k,:) = tem(:,30);
    export31(k,:) = tem(:,31);
    export32(k,:) = tem(:,32);
    export33(k,:) = tem(:,33);
    export34(k,:) = tem(:,34);
    export35(k,:) = tem(:,35);
    export36(k,:) = tem(:,36);
    export37(k,:) = tem(:,37);
    export38(k,:) = tem(:,38);
    export39(k,:) = tem(:,39);
    export40(k,:) = tem(:,40);
    export41(k,:) = tem(:,41);
    export42(k,:) = tem(:,42);
    export43(k,:) = tem(:,43);
    export44(k,:) = tem(:,44);
    export45(k,:) = tem(:,45);
    export46(k,:) = tem(:,46);
    export47(k,:) = tem(:,47);
    export48(k,:) = tem(:,48);
end

expo(1,:) = sum(export1,1)/sim;
expo(2,:) = sum(export2,1)/sim;
expo(3,:) = sum(export3,1)/sim;
expo(4,:) = sum(export4,1)/sim;
expo(5,:) = sum(export5,1)/sim;
expo(6,:) = sum(export6,1)/sim;
expo(7,:) = sum(export7,1)/sim;
expo(8,:) = sum(export8,1)/sim;
expo(9,:) = sum(export9,1)/sim;
expo(10,:) = sum(export10,1)/sim;
expo(11,:) = sum(export11,1)/sim;
expo(12,:) = sum(export12,1)/sim;
expo(13,:) = sum(export13,1)/sim;
expo(14,:) = sum(export14,1)/sim;
expo(15,:) = sum(export15,1)/sim;
expo(16,:) = sum(export16,1)/sim;
expo(17,:) = sum(export17,1)/sim;
expo(18,:) = sum(export18,1)/sim;
expo(19,:) = sum(export19,1)/sim;
expo(20,:) = sum(export20,1)/sim;
expo(21,:) = sum(export21,1)/sim;
expo(22,:) = sum(export22,1)/sim;
expo(23,:) = sum(export23,1)/sim;
expo(24,:) = sum(export24,1)/sim;
expo(25,:) = sum(export25,1)/sim;  %totalV1;
expo(26,:) = sum(export26,1)/sim;  %totalV2;
expo(27,:) = sum(export27,1)/sim;  %totalV1E1;
expo(28,:) = sum(export28,1)/sim;  %totalV1E2;
expo(29,:) = sum(export29,1)/sim;  %totalV1E3;
expo(30,:) = sum(export30,1)/sim;  %totalV2E1;
expo(31,:) = sum(export31,1)/sim;  %totalV2E2;
expo(32,:) = sum(export32,1)/sim;  %totalV2E3;
expo(33,:) = sum(export33,1)/sim;  %totalV1;
expo(34,:) = sum(export34,1)/sim;  %totalV2;
expo(35,:) = sum(export35,1)/sim;  %totalV1E1;
expo(36,:) = sum(export36,1)/sim;  %totalV1E2;
expo(37,:) = sum(export37,1)/sim;  %totalV1E3;
expo(38,:) = sum(export38,1)/sim;  %totalV2E1;
expo(39,:) = sum(export39,1)/sim;  %totalV2E2;
expo(40,:) = sum(export40,1)/sim;  %totalV2E3;
expo(41,:) = sum(export41,1)/sim;  %nuevosH1; % JG0816
expo(42,:) = sum(export42,1)/sim;  %nuevosH2; % JG0816
expo(43,:) = sum(export43,1)/sim;  %nuevosH3; % JG0816
expo(44,:) = sum(export44,1)/sim;  %nuevosUCI1; % JG0816
expo(45,:) = sum(export45,1)/sim;  %nuevosUCI2; % JG0816
expo(46,:) = sum(export46,1)/sim;  %nuevosUCI3; % JG0816
expo(47,:) = sum(export47,1)/sim;  %nuevosH1+nuevosH2+nuevosH3; % JG0816
expo(48,:) = sum(export48,1)/sim;  %nuevosUCI1+nuevosUCI2+nuevosUCI3; % JG0816


TT = table(days',expo(1,:)',expo(2,:)',expo(3,:)',expo(4,:)', expo(5,:)',expo(6,:)',expo(25,:)',expo(26,:)',expo(33,:)',expo(37,:)',expo(47,:)',expo(48,:)');
TT.Properties.VariableNames = {'Fecha','Acumulado','D','H','UCI','Muertes','U','V1','V2','accumV1', 'accumV2','NewHosp','NewUCI'};
writetable(TT,[nombre1 'DatosPais.xlsx'],'Sheet','Pais')

TT = table(days',expo(22,:)',expo(7,:)',expo(8,:)',expo(9,:)',expo(10,:)', expo(11,:)',expo(27,:)',expo(30,:)',expo(34,:)',expo(38,:)',expo(41,:)',expo(44,:)');
TT.Properties.VariableNames = {'Fecha','Acumulado','D','H','UCI','Muertes','U','V1','V2','accumV1','accumV2','NewHospE1', 'NewUCIE1'};
writetable(TT,[nombre1 'DatosPais.xlsx'],'Sheet','E1')

TT = table(days',expo(23,:)',expo(12,:)',expo(13,:)',expo(14,:)',expo(15,:)', expo(16,:)',expo(28,:)',expo(31,:)',expo(35,:)',expo(39,:)',expo(42,:)',expo(45,:)');
TT.Properties.VariableNames = {'Fecha','Acumulado','D','H','UCI','Muertes','U','V1','V2','accumV1','accumV2','NewHospE2','NewUCIE2'};
writetable(TT,[nombre1 'DatosPais.xlsx'],'Sheet','E2')
TT = table(days',expo(24,:)',expo(17,:)',expo(18,:)',expo(19,:)',expo(20,:)', expo(21,:)',expo(29,:)',expo(32,:)',expo(36,:)',expo(40,:)',expo(43,:)',expo(46,:)');
TT.Properties.VariableNames = {'Fecha','Acumulado','D','H','UCI','Muertes','U','V1','V2','accumV1','accumV2','NewHospE3','NewUCIE3'};
writetable(TT,[nombre1 'DatosPais.xlsx'],'Sheet','E3')

%%%%

files  = dir(['./info/' nameFile2 '*.mat']);
files2 = dir(['./info/' nameFile3 '*.mat']);

sim = size(files,1);

dataMap     = zeros(num_cbg,T);
dataMapAcum = zeros(num_cbg,T+1);

for k = 1:sim

%nameFile = [direc '/' nameFile2 num2str(k) '.mat'];
nameFile = [direc files(k).name];
x = load(nameFile);
dataMap = dataMap + double(x.x);

%nameFile = [direc '/' nameFile3 num2str(k) '.mat'];
nameFile = [direc files2(k).name];
x = load(nameFile);
dataMapAcum = dataMapAcum + double(x.x);
end
dataMap     = dataMap/sim;
dataMapAcum = dataMapAcum/sim;


TT = table(days(2:end)',dataMap');
writetable(TT,[nombre1 'CantonesActivos.xlsx'],'Sheet',1)
TT = table(days(1:end)',dataMapAcum');
writetable(TT,[nombre1 'CantonesAcumulados.xlsx'],'Sheet',1)


TT = table(days',export1');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','Acum')
TT = table(days',export2');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','Activo')
TT = table(days',export3');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','Hospitalizados')
TT = table(days',export4');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','UCIs')
TT = table(days',export5');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','Muertes')
TT = table(days',export6');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','NoDiag')
TT = table(days',export25');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','V1')
TT = table(days',export26');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','V2')
TT = table(days',export33');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','accumV1')
TT = table(days',export37');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','accumV2')
TT = table(days',export47');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','accumHosp')
TT = table(days',export48');
writetable(TT,[nombre1 'TotalDatos.xlsx'],'Sheet','accumUCI')
end
function parsave(k,x,dir,nameFile)
nameFile = [dir '/' nameFile num2str(k) '.mat'];
save(nameFile, 'x')
end
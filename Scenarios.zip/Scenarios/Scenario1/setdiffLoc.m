function c = setdiffLoc(a,b)
%a = a(:); % Convert to columns.
%b = b(:);

numelA = numel(a);
% if numelA == 0 || numelB <= 1 % revisa numelA > 0
scalarcut = 5;
if numelA <= scalarcut
    lia = false(size(a));
    for i=1:numelA
        lia(i) = any(a(i)==b(:));
    end
else    
    % Find out whether list is presorted before sort
    sortedlist = issorted(b(:));
    if ~sortedlist
        b = sort(b(:));
    end
    lia = builtin('_ismemberhelper',a,b);
end
c = a(~lia);
%c = unique(c,'sorted');
%c = c.';
end
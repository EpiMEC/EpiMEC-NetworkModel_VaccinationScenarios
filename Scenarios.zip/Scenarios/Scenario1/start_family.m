function [total_people_per_families,idToCounty,idToFamily, ...
    density_per_county,cumsum_people_per_county,idToAge,cumsum_people_per_family] = start_family(dir)

% read demographic data
houses_per_county       = xlsread([dir 'TotalCasosDia'],'Cantones','G2:G82');
population_per_county   = xlsread([dir 'TotalCasosDia'],'Cantones','E2:E82');
density_per_county      = xlsread([dir 'TotalCasosDia'],'Cantones','F2:F82');
age_by_group            = xlsread([dir 'TotalCasosDia'],'Cantones','H2:J82');

% total number of houses
total_houses = sum(houses_per_county);

% allocate arrays
number_people_county      = nan(1,81);                     % population per county
total_people_per_families = zeros(1,total_houses,'uint8'); % people per family
order_people_by_age       = cell(1,81);                    % age for each ID per county

% create families based on Poisson distribution
index = 0;
for j = 1:81
    loc_houses        = houses_per_county(j);
    loc_population    = population_per_county(j);
    average_per_house = loc_population/loc_houses;
    % create distribution for number of individuals per family
    number_people_per_house = poissrnd(average_per_house-1,loc_houses,1)+1;
    % store number of people per family
    adv = numel(number_people_per_house);
    total_people_per_families(index+1:index+adv) = number_people_per_house;
    index = index + adv;
    % correct number of people per county (due to the random distribution)
    number_people_county(j) = sum(number_people_per_house);
    % include age: percentage by group
    ratios = age_by_group(j,:)/sum(age_by_group(j,:));
    n1 = floor(ratios(1)*number_people_county(j));
    n2 = floor(ratios(2)*number_people_county(j));
    n3 = number_people_county(j)-n1-n2;
    % create number of people per age
    age_groups = [ones(1,n1), 2*ones(1,n2), 3*ones(1,n3)];
    % uniformly sort age groups
    order_people_by_age{j} = age_groups(randperm(number_people_county(j)));
end

% accumulate sums for families and counties
cumsum_people_per_family = [0 cumsum(uint32(total_people_per_families))];
cumsum_people_per_county = [0 cumsum(number_people_county)];

% allocate arrays to avoid searches
idToAge    = zeros(1,cumsum_people_per_family(end),'uint8');  % ID to age group: 1<->0-18, 2<->18-65, 3<->65-)
idToFamily = zeros(1,cumsum_people_per_family(end),'uint32'); % ID to family
idToCounty = zeros(1,cumsum_people_per_county(end),'uint8');  % ID to county

% fill idToCounty and idToAge
index = 0;
for j = 1:81
    idToCounty(cumsum_people_per_county(j)+1:cumsum_people_per_county(j+1)) = j;
    adv = numel(order_people_by_age{j});
    idToAge(index+1:index+adv) = order_people_by_age{j};
    index = index + adv;
end

% fill idToFamily
for j = 1:total_houses
    idToFamily(cumsum_people_per_family(j)+1:cumsum_people_per_family(j+1)) = j;
end

end